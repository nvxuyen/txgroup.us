@extends('client.master')
@section('content')
<div class="page_title">

	<div class="container">
		<div class="leaft_title"><h1>Điều khoản dịch vụ</h1></div>
        <div class="reght_pagenation"><a href="/">Trang chủ</a> <i>/</i> Điều khoản dịch vụ</div>
	</div>
    
</div><!-- end page title -->


<div class="clearfix"></div>

<div class="container">

	<div class="content_fullwidth">

		<div class="one_full">
        
			<p>Bằng việc đăng ký sử dụng phần mềm điều khiển máy tính từ xa của UltraViewer (tạm gọi tắt là "Dịch vụ" hoặc "UltraViewer"), bạn đồng ý cam kết với các điều khoản và điều kiện sau đây (gọi chung là "Điều khoản sử dụng"). UltraViewer có quyền chỉnh sửa, cập nhật các quy định và điều kiện này bất cứ lúc nào mà không cần báo trước. Việc chỉnh sửa này sẽ có hiệu lực ngay khi được cập nhật trên website của UltraViewer.net. Bạn nên thường xuyên kiểm tra, cập nhật lại những quy định trong Điều khoản sử dụng này để đảm bảo quyền lợi của mình một cách đầy đủ nhất.</p>
            
         </div><!-- end dropcaps -->
            
            
            <div class="clearfix divider_line"></div>
            
        <div class="one_full">
        	<h2>Điều kiện sử dụng tài khoản</h2>
			<p>1. Bạn có trách nhiệm giữ tài khoản và mật khẩu của mình an toàn. UltraViewer cam kết và có trách nhiệm mã hóa mật khẩu một cách bảo mật, nhưng sẽ không chịu trách nhiệm cho bất kỳ tổn thất hoặc thiệt hại từ sự thiếu cẩn trọng của bạn trong việc bảo mật thông tin tài khoản.</p>
			<div class="mar_top2"></div>
            <p>2. Cung cấp các thông tin chính xác, cam kết các thông tin của bạn là chính xác khi đăng ký sử dụng dịch vụ của UltraViewer.</p>
			<div class="mar_top2"></div>
			<p>3. Không sử dụng phần mềm UltraViewer vào mục đích vi phạm pháp luật, phá hoại, hoặc gây hại cho người khác.</p>
			<div class="mar_top2"></div>
			<p>4. Không sử dụng thẻ tín dụng đánh cắp của người khác để thanh toán mua hàng trên website của chúng tôi</p>
			<div class="mar_top2"></div>	
			<p>5. Không chủ định tấn công, dịch ngược, bẻ khóa, gian lận bản quyền phần mềm UltraViewer.<p>
			<div class="mar_top2"></div>
			<p>6. Nếu bạn vi phạm các quy định sử dụng, UltraViewer có quyền dừng việc sử dụng dịch vụ của bạn.</p>
			<div class="mar_top2"></div>
			<div class="mar_top2"></div>
         </div><!-- end blockquotes -->
            
           
          
		   <div class="one_full">
        	<h2>Quyền và trách nghiệm của chúng tôi</h2>
			<p>1. Hỗ trợ: UltraViewer có trách nghiệm cung cấp cho khách hàng các phương thức hỗ trợ thích hợp như qua điện thoại, qua chat, qua email ...</p>
			<div class="mar_top2"></div>
			<p>2. Bảo mật: chính sách bảo mật của UltraViewer giải thích cách chúng tôi xử lý dữ liệu cá nhân của bạn và bảo vệ sự riêng tư của bạn khi bạn sử dụng Dịch vụ của chúng tôi. Chúng tôi có trách nghiệm lưu trữ, mã hóa các thông tin của bạn một cách bảo mật nhất và không cung cấp cho bất kì bên thứ 3 nào khác.</p>
			<div class="mar_top2"></div>
			<p>3. Cam kết an toàn: Chúng tôi cam kết phần mềm UltraViewer không đính kèm bất kì mã độc, trojan, virus gây hại nào cho máy tính của bạn. Chúng tôi chịu hoàn toàn trách nghiệm trước pháp luật , cũng như uy tín, lương tâm về các sản phẩm của mình. Chúng tôi không mất công xây dựng sản phẩm, gây dựng thương hiệu trong thời gian dài để rồi phá hủy thương hiệu của mình. Vì vậy bạn có thể hoàn toàn yên tâm sử dụng sản phẩm của chúng tôi.</p>
			<div class="mar_top2"></div>
			<div class="mar_top2"></div>
         </div><!-- end blockquotes -->
		 
		
		 

</div>

</div><!-- end hosting plan details -->
@endsection