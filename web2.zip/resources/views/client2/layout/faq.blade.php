@extends('client.master')
@section('content')
<div class="page_title">

	<div class="container">
		<div class="leaft_title"><h1>Trung tâm hỗ trợ</h1></div>
        <div class="reght_pagenation"><a href="">Trang chủ</a> <i>/</i> <a href="#">Hướng dẫn</a></div>
	</div>
    
</div><!-- end page title -->

<div class="clearfix"></div>


<div class="container">

	<div class="content_left">
    
    <div class="accrodation_full">
        
    	<h2>Các câu hỏi thường gặp</h2>
        @foreach($faq as $f)
    	<span class='acc-trigger'><a href='#'>{{$f->title}}</a></span>
        <div class='acc-container'>
            <div class='content'>{{$f->content}}</div>
        </div>
        @endforeach
    </div>
    
</div><!-- end content left area -->


<!-- right sidebar starts -->
<div class="right_sidebar">
    
    <div class="sidebar_widget">
    
    	<div class="sidebar_title"><h3>Trợ giúp</h3></div>
        
			<ul class="sidebar_item_list">
                
                <li>
                <span><a href="{{route('lien-he')}}"><img src="public/assets/images/home/tickets-icon.png" alt="Ticket" /></a></span>
                <a href="{{route('lien-he')}}">Gửi câu hỏi</a>
                <i>Bạn còn câu hỏi nào không? Hãy gửi yêu cầu của bạn cho chúng tôi.</i> 
                </li>
                
                <li class="last">
                <span><a href="{{route('lien-he')}}"><img src="public/assets/images/home/phone-icon.png" alt="Phone Support" /></a></span>
                <a href="{{route('lien-he')}}">Hỗ trợ qua điện thoại</a>
                <i>Bạn cần hỗ trợ qua điện thoại ? Hãy gọi cho chúng tôi.</i> 
                </li>
                        
            </ul>
                
	</div><!-- end section -->
    
    <div class="clearfix mar_top3"></div> 
    
    <div class="sidebar_widget">

		<h3>Hỗ trợ khác</h3>
		
        <p>Nếu bạn có câu hỏi nào khác, hãy gửi câu hỏi cho chúng tôi qua hình thức gửi thẻ hoặc qua Live Chat. </p>

                
	</div><!-- end section -->

	
</div><!-- end right sidebar -->


</div>
@endsection