@extends('client.master')
@section('content')
<div class="page_title">

	<div class="container">
		<div class="leaft_title"><h1>Liên hệ - Hỗ trợ</h1></div>
        <div class="reght_pagenation"><a href="">Trang chủ</a> <i>/</i> Liên hệ</div>
	</div>
    
</div><!-- end page title -->

<div class="clearfix"></div>

<script type="text/javascript" src="https://www.skypeassets.com/i/scom/js/skype-uri.js"></script>
<div class="container">

	<div class="content_left">
            
            <div class="our_support">
			
            <h3>Bán hàng</h3>
			
                <h5><img src="public/assets/images/email-icon.png" alt="" />E-mail</h5>  
                <p><strong><a href="mailto:sales@ultraviewer.net">sales@txgroup.us</a></strong></p>
                <br />
				<h5><img src="public/assets/images/email-icon.png" alt="" />Skype</h5>  
                <p><a href="skype:txgroup?chat"><img style="width:130px" src="public/assets/images/skype_chat_button.png"/></a></p>
				<br />
                <h5><img src="images/clock-icon.png" alt="" />Thời gian</h5>  
                <p><strong>Hãy gọi cho chúng tôi từ thứ Hai đến thứ Sáu, 9 giờ sáng - 5 giờ chiều ( GMT + 7 )</strong></p>
            
            </div>

            
            <div class="our_support last">
            <h3>Hỗ trợ kĩ thuật</h3>
			
                <h5><img src="public/assets/images/email-icon.png" alt="" />E-mail</h5>  
                <p><strong><a href="mailto:support@txgroup.us">support@txgroup.us</a></strong></p>

                <br />
                <h5><img src="public/assets/images/clock-icon.png" alt="" />Thời gian</h5>  
                <p><strong>Hãy gọi cho chúng tôi từ thứ Hai đến thứ Sáu, 9 giờ sáng - 5 giờ chiều ( GMT + 7 )</strong></p>
            
            </div>
            
            <div class="clearfix mar_top3"></div>
            
          
			<div class="address-info">
            <h3>Đơn vị chủ quản</h3>
                <ul>
                <li>
                <strong>TRƯỜNG ĐẠI HỌC CÔNG NGHỆ SÀI GÒN</strong><br />
                Số 180 Cao Lỗ, Quận 8, TP.HCM, Việt Nam<br />
                Điện thoại: +84 909.999.999<br />
                <!--FAX: +1 0123-4567-8900<br />-->
                E-mail: <a href="mailto:contact@txgroup.us">contact@txgroup.us</a><br />
                <!--Website: <a href="index.html">www.yoursitename.com</a>-->
                </li>
            </ul>
        </div>
	<div class="one_half">
        
	</div>
		
		
        </div><!-- end content left area -->

		
<!-- right sidebar starts -->
<div class="right_sidebar">

	<div class="sidebar_widget">
    	<h3>Câu hỏi chung</h3>
		<ul class="arrows_list1">		
            <li><a href="{{route('trang-chu')}}">Trang chủ</a></li>
            <li><a href="#">Giới thiệu</a></li>
            <li><a href="https://goo.gl/maps/3GLp8BsQ9iF2" target="_blank">Bản đồ</a></li>
		</ul>
	</div><!-- end section -->
    
</div><!-- end right sidebar -->


</div>
@endsection