@extends('client.master')
@section('content')
<div class="page_title">

    <div class="container">
        <div class="leaft_title"><h1>Phòng của tôi</h1></div>
        <div class="reght_pagenation"><a href="/">Trang chủ</a> <i>/</i> Phòng của tôi</div>
    </div>
    
</div><!-- end page title -->
<style>
table { 
    width: 100%; 
    border-collapse: collapse; 
    margin:50px auto;
    }

/* Zebra striping */
tr:nth-of-type(odd) { 
    background: #eee; 
    }

th { 
    background: #35b2e8; 
    color: white; 
    font-weight: bold; 
    }

td, th { 
    padding: 10px; 
    border: 1px solid #ccc; 
    text-align: left; 
    font-size: 14px;
    }
</style>
</style>
<div class="clearfix"></div>

<div class="container">

    <div class="content_fullwidth">
@if(count($room) > 0)

<table id="dynamic-table" class="table table-striped table-bordered table-hover">
    <thead>
        <tr>
            <th width="5%">#Mã</th>
            <th width="8%">Tên phòng</th>
            <th width="5%">Ca</th>
            <th width="15%">Thời gian bắt đầu</th>
            <th width="15%">Thời gian kết thúc</th>
            <th width="10%">Ngày</th>
            <th width="12%">Thời gian cập nhật</th>
            <th width="10%">Trạng thái</th>
        </tr>
    </thead>

    <tbody>
        @foreach($room as $r)                                                
        <tr>
            <td><b>#{{$r->id}}</b></td>
            <td>{{$r->name}}</td>
            <td>{{$r->ca}}</td>
            <td>{{$r->time_start}}</td>
            <td>{{$r->time_end}}</td>
            <td>{{\Carbon\Carbon::parse($r->date)->format('d-m-Y')}}</td>
            <td>{{\Carbon\Carbon::parse($r->updated_at)->format('d-m-Y H:s:i')}}</td>
            <td>
                @if($r->status == 3) 
                Đã xác nhận 
                @elseif($r->status == 2) 
                Đã hủy
                @else 
                Chờ xử lý | <a href="{{route('trang-chu')}}/room/history/cancle/{{$r->id}}"><font color="red">HỦY</font></a>@endif
            </td>
        </tr>
        @endforeach
       
                                                        
    </tbody>
</table>
@else
<center><h2>Hiện tại bạn chưa mượn phòng nào</h2></center>
@endif

</div>

</div><!-- end hosting plan details -->

@endsection