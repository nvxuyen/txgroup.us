@extends('client.master')
@section('content')
<div class="page_title">

	<div class="container">
		<div class="leaft_title"><h1>Đăng ký tài khoản</h1></div>
        <div class="reght_pagenation"><a href="/">Trang chủ</a> <i>/</i> Đăng ký</div>
	</div>
    
</div><!-- end page title -->
<link rel="stylesheet" type="text/css" href="{{ asset('') }}public/assets/css/register.css">

<section class="signup">
    <!-- <img src="images/signup-bg.jpg" alt=""> -->
    <div class="container-2">
        <div class="signup-content">
            <form action="{{route('verify_change_pass',['code' => $code])}}" method="POST" id="signup-form" class="signup-form">
            	<input type="hidden" name="_token" value="{{csrf_token()}}">
                <h2 class="form-title">THAY ĐỔI MẬT KHẨU</h2>

				@if(count($errors) > 0)
				@foreach($errors->all() as $err)
					<div class="alert alert-warning">
					    <strong>Cảnh báo!</strong> {{$err}}
				 	 </div>
				@endforeach
				@endif
				
				@if(session('thongbao'))
				  <div class="alert alert-success">
				    <strong>Thành công!</strong><br>
                    {{session('thongbao')}}
				  </div>
			  	@endif
                @if(isset($error))
                    <div class="alert alert-warning">
                        <strong>Cảnh báo!</strong> {{$error}}
                     </div>
                @elseif($checkEnable == 1)
                <div class="form-group">
                    <input type="password" class="form-input" name="password" id="password" placeholder="Mật khẩu"/>
                    <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>
                </div>
                <div class="form-group">
                    <input type="password" class="form-input" name="repassword" id="repassword" placeholder="Nhập lại mật khẩu"/>
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" id="submit" class="form-submit" value="Thay đổi mật khẩu"/>
                </div>
                @endif
            </form>
            <p class="loginhere">
                Bạn đã có tài khoản ? Đăng nhập <a href="{{ route('login') }}" class="loginhere-link"> tại đây</a>
            </p>
        </div>
    </div>
</section>


@endsection