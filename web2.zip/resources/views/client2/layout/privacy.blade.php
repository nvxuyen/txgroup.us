@extends('client.master')
@section('content')
<div class="page_title">

	<div class="container">
		<div class="leaft_title"><h1>Chính sách bảo mật</h1></div>
        <div class="reght_pagenation"><a href="/">Trang chủ</a> <i>/</i> Chính sách bảo mật</div>
	</div>
    
</div><!-- end page title -->


<div class="clearfix"></div>

<div class="container">

	<div class="content_fullwidth">

		<div class="one_full">
        
			<h6>UltraViewer tôn trọng và cam kết sẽ bảo mật những thông tin mang tính riêng tư của bạn. Chính sách bảo mật này được áp dụng cho tất cả các sản phẩm và dịch vụ do UltraViewer cung cấp. Xin vui lòng đọc kỹ bản Chính sách bảo mật dưới đây để hiểu hơn những cam kết mà chúng tôi thực hiện nhằm tôn trọng và bảo vệ quyền lợi của bạn:</h6>
            
         </div><!-- end dropcaps -->
            
            
            <div class="clearfix divider_line"></div>
            
        <div class="one_full">
        	<h2>Chính sách bảo mật của UltraViewer</h2>
			<p><strong>1. Khi bạn đăng ký một tài khoản mới trên UltraViewer</strong>, chúng tôi có thể yêu cầu bạn cung cấp thông tin cá nhân như họ tên, đơn vị công tác, địa chỉ email, địa chỉ liên lạc, thông tin thẻ thanh toán/ thẻ tín dụng vv ... Chúng tôi sẽ sử dụng thông tin cá nhân đó để hỗ trợ cho việc cung cấp dịch vụ tới bạn như gửi thông báo về những cập nhật mới trong dịch vụ hay gửi cho bạn những thông tin về các chương trình khuyến mại, các hoạt động quảng bá liên quan đến sản phẩm và dịch vụ, ngoài ra chúng tôi cam kết không sử dụng cho bất kỳ mục đích nào khác.</p>
			<div class="mar_top2"></div>
            <p><strong>2. Bằng việc sử dụng dịch vụ</strong>, bạn đồng ý với việc sử dụng các tập tin cookie, thông tin truy cập, hình ảnh để vận hành dịch vụ, chỉnh sửa thông tin và nội dung cá nhân; lưu trữ thông tin trên máy để bạn tiết kiệm thời gian bằng cách giảm thiểu sự rắc rối khi liên tục nhập các thông tin tương tự, để hiển thị nội dung cá nhân, hay để những thông tin quảng cáo phù hợp được lưu trữ và xuất hiện lại cho lần ghé thăm tiếp theo của bạn trên website.</p>
			<div class="mar_top2"></div>
			<p><strong>3. UltraViewer cam kết không trao đổi hay mua bán dữ liệu cá nhân của bạn cho các bên thứ ba</strong>. Chúng tôi không chia sẻ, mua bán, thương mại hóa thông tin cá nhân của bạn cho bất kì bên nào khác, trừ nghĩa vụ tiết lộ thông tin cho bên thứ ba về những vấn đề liên quan đến pháp luật, chẳng hạn như thực hiện theo một phiên hầu tòa, hoặc quá trình pháp lý tương tự, việc tiết lộ thông tin là cần thiết để bảo vệ quyền lợi của UltraViewer, bảo vệ sự an toàn của bạn và những người xung quanh, điều tra gian lận, hoặc trả lời những yêu cầu của chính phủ.</p>
			<div class="mar_top2"></div>
			<p><strong>4. Mật khẩu của bạn khi đăng ký trên UltraViewer đã được mã hóa an toàn</strong> theo đúng quy định của pháp luật, chúng tôi áp dụng lớp mã hóa 1 chiều nên trong trường hợp xấu nhất tin tặc dù có khai thác được cơ sở dữ liệu cũng không thể nhìn thấy mật khẩu của quý khách.</p>
			<div class="mar_top2"></div>
			<div class="mar_top2"></div>
         </div><!-- end blockquotes -->
            
           
           <div class="one_full">
        	<h2>Chương trình tiếp thị kinh doanh mạng</h2>
			<p>UltraViewer có thể cung cấp các thông tin sau cho người đã giới thiệu bạn trong chương trình Affiliate, bao gồm : <br> - Tên máy tính của bạn, số ID đã được che những kí tự đầu hoặc cuối, ngày giờ và thời gian bạn được thới thiệu.</p>
			<div class="mar_top2"></div>
			<div class="mar_top2"></div>
         </div><!-- end blockquotes -->
            
           

</div>

</div><!-- end hosting plan details -->

@endsection