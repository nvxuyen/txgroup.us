      <div class="container_full">
    
        <div class="top_links">
            <div class="container">
                
            <div class="date_wrap">
            <b class='date'></b>
            
            <script type="text/javascript">
            function changeLanguage(loc) {
            window.location = window.location.href.replace( /\/vi\//i , '/' + loc.options[loc.selectedIndex].value + '/');
            expireDate = new Date();
            expireDate.setTime(expireDate.getTime() + (86400000)); // 1 Tag
            document.cookie = "language=" + loc.options[loc.selectedIndex].value + "; expires=" + expireDate.toUTCString() + "; path=/";
            }
            </script>
            
            </div><!-- end date -->
            
            <div class="top_contact_info">
                    <ul class="tci_list">   
                        <li class="chat"><a href="skype:txgroup_support?chat">Hỗ trợ Skype</a></li>
                        <li class="phone">Hotline : 0999.999.999</li>
                        <li><a target="_blank" href="https://www.facebook.com/DHCNSG//"><img src="public/assets/images/top_si1.png" alt="Facebook" /></a></li>
                        <li><a href="#"><img src="public/assets/images/top_si2.png" alt="" /></a></li>
                        <li><a href="#"><img src="public/assets/images/top_si3.png" alt="" /></a></li>
                        <li><a href="#"><img src="public/assets/images/top_si4.png" alt="" /></a></li>
                        <li><a href="#"><img src="public/assets/images/top_si5.png" alt="" /></a></li>  
                        @if(Auth::check())
                        <li class="email"> 
                        <div class="dropdown">
                          <a onclick="myFunction()" class="dropbtn">Xin chào : {{Auth::user()->full_name}} ▼</a>
                          
                          <div id="myDropdown" class="dropdown-content">
                            @if((Auth::user()->level) == 2)
                            <a href="{{route('admin')}}">Trang quản lý</a>
                            @endif
                            <a href="{{route('room-history')}}">Phòng của tôi</a>
                            <a href="{{route('trang-chu')}}/profile">Thay đổi thông tin</a>
                            <a href="{{route('logout')}}">Đăng xuất</a>
                             
                          </div>
                        </div>
                        </li>
                        @else
                        <li class="email"> 
                        <div class="dropdown">
                          <a onclick="myFunction()" class="dropbtn">Đăng nhập  ▼</a>
                          
                          <div id="myDropdown" class="dropdown-content">
                            <a href="{{route('login')}}">Đăng nhập</a>
                            <a href="{{route('register')}}">Đăng ký</a>
                            <a href="{{route('forgotpassword')}}">Quên mật khẩu?</a>
                             
                          </div>
                        </div>
                        </li>
                        @endif
                    </ul>
            </div><!-- end top contact info -->
                
            
            </div>
        </div><!-- end top links -->
        <div class="top_section">

        <div class="container">

            <div id="logo">
            <div class="logo_container" style="display: inline; float:left; margin-top:15px; margin-right:10px" >
            <img src="public/assets/images/logo.png"/>
            </div>
            <a href="{{route('trang-chu')}}" class="site_logo" style="display:inline;"><h1>TX<i>GROUP</i></h1></a></div><!-- end logo -->

            <nav id="access" class="access" role="navigation">

            
                <div id="menu" class="menu">
                    
                    <ul id="tiny">
                        <li><a href="{{route('trang-chu')}}"  class="{{isset($index_page) ? $index_page : ''}}">Trang chủ</a></li>
                        <li><a href="{{route('room')}}" class="{{isset($room_page) ? $room_page : ''}}" >Danh sách phòng</a></li>
                        <li><a href="{{route('faq')}}" class="{{isset($faq_page) ? $faq_page : ''}}" >Hướng dẫn</a></li>
                        <li><a href="{{route('blog')}}" class="{{isset($blog_page) ? $blog_page : ''}}">Blog</a></li>
                        <li><a href="{{route('lien-he')}}" class="{{isset($contact_page) ? $contact_page : ''}}">Liên hệ</a></li>
                    </ul>
                    
                </div>
                

            </nav>
                

        </div> 
    </div>