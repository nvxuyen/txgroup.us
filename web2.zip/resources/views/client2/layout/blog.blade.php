@extends('client.master')
@section('content')

<style type="text/css">
	.blog_postcontent .image_frame.small {
    float: left;
    width: 25%;
    border: 7px solid #fff;
    margin-bottom: 25px;
    -webkit-box-shadow: 0px 0px 3px 0px rgba(0, 0, 0, 0.1);
    box-shadow: 0px 0px 3px 0px rgba(0, 0, 0, 0.1);
}

.pagination {
    padding-left: 0;
    margin: 20px 0;
    border-radius: 4px;
}
.pagination>li {
    display: inline;
}
.pagination>li:first-child>a, .pagination>li:first-child>span {
    margin-left: 0;
    border-bottom-left-radius: 4px;
    border-top-left-radius: 4px;
}
.pagination>.disabled>a, .pagination>.disabled>a:focus, .pagination>.disabled>a:hover, .pagination>.disabled>span, .pagination>.disabled>span:focus, .pagination>.disabled>span:hover {
    color: #777;
    background-color: #fff;
    border-color: #ddd;
    cursor: not-allowed;
}
.pagination>.active>a, .pagination>.active>a:focus, .pagination>.active>a:hover, .pagination>.active>span, .pagination>.active>span:focus, .pagination>.active>span:hover {
    z-index: 3;
    color: #fff;
    background-color: #337ab7;
    border-color: #337ab7;
    cursor: default;
}
.pager>li>a, .pagination>li>a {
    border-width: 1px;
    border-color: #d4dfe3;
    color: #2283C5;
    background-color: #FAFAFA;
    margin: 0 -1px 0 0;
    position: relative;
    z-index: auto;
}
.pagination>li>a, .pagination>li>span {
    position: relative;
    float: left;
    padding: 6px 12px;
    line-height: 1.42857143;
    text-decoration: none;
    color: #337ab7;
    background-color: #fff;
    border: 1px solid #ddd;
    margin-left: -1px;
}
</style>
<div class="page_title">

	<div class="container">
		<div class="leaft_title"><h1>Blog</h1></div>
        <div class="reght_pagenation"><a href="">Trang chủ</a> <i>/</i> Blog</div>
	</div>
    
</div><!-- end page title -->

<div class="clearfix"></div>

<div class="container">

	<div class="content_left">
        	
        	@foreach($news as $n)
       		<div class="blog_post">	
				<div class="blog_postcontent">
				
                <div class="image_frame small"><a href="#"><img src="@if($n->image==NULL) public/assets/images/default.png @else {{$n->image}} @endif" alt="" /></a></div>
                <div class="post_info_content_small">
				
				 <a href="#" class="date"><strong>{{\Carbon\Carbon::parse($n->created_at)->format('d')}}</strong><i>Tháng {{\Carbon\Carbon::parse($n->created_at)->format('m')}}</i></a>
				<h1><a href="{{route('blog')}}/readmore/{{$n->id}}/{{$n->title_ascii}}.html">{{$n->title}}</a></h1>
                    <ul class="post_meta_links_small">
                        <li class="post_categoty"><a href="">{{$n->name}}</a></li>
                        <li class="post_comments"><a href="#">0 bình luận</a></li>
                    </ul>
                <div class="clearfix"></div>
                 
				
                <p>{{$n->quote}}</p>
                
                </div>
				</div>
			</div><!-- /# end post -->
			@endforeach
            
            <div class="clearfix divider_line3"></div>   
            
            {{$news->links()}}
        
        </div><!-- end content left area -->


<!-- right sidebar starts -->
<div class="right_sidebar">
	
    <div class="site-search-area">
        <form method="get" id="site-searchform" action="blog.html">
        <div>
        <input class="input-text" name="s" id="s" value="Tìm kiếm..." onFocus="if (this.value == 'Tìm kiếm...') {this.value = '';}" onBlur="if (this.value == '') {this.value = 'Tìm kiếm...';}" type="text" />
        <input id="searchsubmit" value="Search" type="submit" />
        </div>
        </form>
	</div><!-- end site search -->
    
    <div class="clearfix mar_top3"></div>
    
	<div class="sidebar_widget">
    	<div class="sidebar_title"><h3>Danh mục</h3></div>
		
		<ul class="arrows_list1">			
			<li><a  class="active" href="{{route('blog')}}">Tất cả</a></li>
			@foreach($loai_news as $loai)
				<li><a  href="{{route('blog')}}/cat/{{$loai->id}}/{{$loai->name_ascii}}.html">{{$loai->name}}</a></li>
			@endforeach

		</ul>
	</div><!-- end section -->
</div><!-- end right sidebar -->
</div>
@endsection