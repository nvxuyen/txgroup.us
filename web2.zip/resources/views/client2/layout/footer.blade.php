<div class="container_full">

    <div class="twitter_feed">
    
        <div class="container">
        
            <img src="public/assets/images/twitter-bird.png" alt="" class="image_left1" >
            
            <div class="tweets"><strong>TXGROUP:</strong> Trang web hỗ trợ mượn phòng tại trường STU trực tuyến. <br />
                
            </div>
        
        </div>
    
    </div>

</div>

<!-- Footer
======================================= -->

<div id="footer">
    
    <div class="container">
        
        <div class="column">
        
            <h2>Về TXGROUP</h2>
            <p>TXGROUP mang đến giải phòng cho mượn phòng học, hội trường khi không sử dụng của trường Đại Học Công Nghệ Sài Gòn.</p>
        
        </div><!-- end about -->
 
        <div class="column">
        
            <h2>Liên kết</h2>
            
            <ul class="list">
            <li><a href="room">Danh sách phòng</a></li>
            <li><a href="faq">Hướng dẫn</a></li>
            <li><a href="lien-he">Liên hệ</a></li>
            <li><a href="tos">Điều khoản sử dụng</a></li>
            <li><a href="privacy">Chính sách bảo mật</a></li>
            </ul>
        
        </div><!-- end support links -->
        
        <div class="column">
        
            <h2>Hướng dẫn</h2>
            
            <ul class="list">
            <li><a href="#">Cách sử dụng</a></li>
            <li><a href="#">Cách thanh toán</a></li>
            <li><a href="#">Bảo mật</a></li>
            <li><a href="#">Hướng dẫn</a></li>
            <li><a href="{{route('blog')}}">Blog</a></li>
            </ul>
        
        </div><!-- end support links -->
        
        <div class="column">
        
            <h2>Liên hệ với chúng tôi</h2>
            
            <ul class="address-liste">
                <li>180 Cao Lỗ, <br>Quận 8<br />TP HCM, Việt Nam</li>
                <li class="icon2">+84 999.999.999</li>
                <li class="icon4"><a href="mailto:nvxuyen@txgroup.us">mailto:nvxuyen@txgroup.us</a></li>
                <li class="icon4"><a href="mailto:pmtriet@txgroup.us">mailto:pmtriet@txgroup.us</a></li>
            </ul>
        
        </div><!-- end address -->
        
        <div class="column last">
        
            <h2>Theo dõi chúng tôi</h2>
            
            <ul class="social_list"> 
                <li><a target="_blank" href="https://www.facebook.com/DHCNSG/"><img src="public/assets/images/social-icon1.png" alt="Facebook" /></a></li>
                <li><a href="#"><img src="public/assets/images/social-icon2.png" alt="" /></a></li>
                <li><a href="#"><img src="public/assets/images/social-icon3.png" alt="" /></a></li>
                <li><a href="#"><img src="public/assets/images/social-icon4.png" alt="" /></a></li>
                <li><a href="#"><img src="public/assets/images/social-icon5.png" alt="" /></a></li>
                <li><a href="#"><img src="public/assets/images/social-icon6.png" alt="" /></a></li>
                <li><a href="#"><img src="public/assets/images/social-icon7.png" alt="" /></a></li>
                <li><a href="#"><img src="public/assets/images/social-icon8.png" alt="" /></a></li>
            </ul>
            
            <div class="clearfix"></div>
            
            <div class="live_chat"><a href="#"><img src="public/assets/images/chat.png" alt="" /><h2>live chat</h2></a></div>
            
        </div><!-- end socails -->
    
    </div>
    
    <div class="clearfix"></div>
    <div class="mar_top2"></div>
    
    <div class="container">
    
        <div class="h_column_area">
        
            <div class="newsletter">
            
                <img src="public/assets/images/newsletter-icon.png" alt="" class="image_left1" /><h4>Nhận<br />Email</h4>
                
                <form method="POST" action="{{route('reg-mail')}}">   
                    {{csrf_field()}}
                    <input class="enter_email_input" name="samplees" id="samplees" value="Nhập email của bạn" onFocus="if(this.value == 'Nhập email của bạn') {this.value = '';}" onBlur="if (this.value == '') {this.value = 'Nhập email của bạn';}" type="text">
                    <input name="" value="Đăng ký" class="input_submit" type="submit">
                    </form>
                
            </div><!-- end newsletter sign up -->
            
            
            <div class="clients">
            
                <h4>Đối tác của<br />TXGROUP</h4>
                
                <ul class="clients_list">
                    <li><img src="public/assets/images/client-logo1.png" alt="" /></li>
                    <li><img src="public/assets/images/client-logo2.png" alt="" /></li>
                    <li><img src="public/assets/images/client-logo3.png" alt="" /></li>
                </ul>
            
            </div><!-- end client logos -->
            
            
        </div>
    
    </div>
    

</div>

<div class="copyright_info">
    
        <div class="container">
        
        <div class="one_half">
            <span><a href="#">Terms of Service</a> | <a href="#">Privacy Policy</a></span>
                    
        </div>
        
        <div class="one_half last"><b>@ Copyright TXGROUP 2018</b></div>
        
        
        
        </div>
        
</div><!-- end copyright info --> 


<a href="#" class="scrollup">Scroll</a><!-- end scroll to top of the page-->
   