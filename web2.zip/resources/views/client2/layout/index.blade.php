@extends('client.master')
@section('content')
<div class="container_full">

    
    <div class="slider_mer_minus">
    
    <div class="fullwidthbanner-container">
        <div class="fullwidthbanner">
        
                        <ul>
                            <!-- SLIDE 1 -->
                            <li data-transition="fade" data-slotamount="10" data-thumb="images/spacer.gif">

                                <img src="public/assets/images/spacer.gif" alt="" />
                          
                                <div class="caption lfr" data-x="460" data-y="50" data-speed="300" data-start="1" data-easing="easeOutBack"><img src="public/assets/images/home/remote-control-software.png" alt="Hệ thống mượn phòng học STU" /></div>
                                <h1 class="caption lft big_orange"  data-x="4" data-y="25" data-speed="500" data-start="100" data-easing="easeOutExpo">Hệ thống mượn phòng của STU</h1>
                                <div class="caption lfl medium_grey"  data-x="4" data-y="80" data-speed="1000" data-start="200" data-easing="easeOutExpo" style="font-size:15px;">Hệ thống Website của TXGroup ra đời nhằm<br>hỗ trợ đặt mượn phòng trực tuyến.</div>
                                <div class="caption sfb" data-x="4" data-y="152" data-speed="300" data-start="1100" data-easing="easeOutExpo"><img src="public/assets/images/sliders/revolution/check.png" alt="" class="sright_icon" /></div>
                                <div class="caption lfb small_text"  data-x="34" data-y="150" data-speed="300" data-start="1100" data-easing="easeOutExpo">Hệ thống có giao diện trực quan - dễ sử dụng</div>
                                <div class="caption sfb" data-x="4" data-y="182" data-speed="300" data-start="1200" data-easing="easeOutExpo"><img src="public/assets/images/sliders/revolution/check.png" alt="" class="sright_icon" /></div>
                                <div class="caption lfb small_text"  data-x="34" data-y="180" data-speed="300" data-start="1200" data-easing="easeOutExpo">Mượn phòng chia theo ca linh hoạt</div>
                                <div class="caption sfb" data-x="4" data-y="212" data-speed="300" data-start="1300" data-easing="easeOutExpo"><img src="public/assets/images/sliders/revolution/check.png" alt="" class="sright_icon" /></div>
                                <div class="caption lfb small_text"  data-x="34" data-y="210" data-speed="300" data-start="1300" data-easing="easeOutExpo">Đặt mượn phòng dễ dàng - nhanh chóng - thuận tiện</div>

                                <div class="caption sfb" data-x="171" data-y="316" data-speed="300" data-start="2000" data-easing="easeOutExpo"><a href="{{route('room')}}" class="slider_button2">Đặt ngay&nbsp;&nbsp;&nbsp;</a></div>

                            </li>
                            
                     
                           
                            
                        </ul>
                        
                    </div>
                    
                </div>
                
                </div>

</div><!-- end slider -->

<div class="clearfix mar_top3"></div>

<div class="bottom_sections">

    <div class="container">
        
        <div class="whyus">
        
            <h2>Tại sao lại chọn chúng tôi?</h2>
            
            <div class="whyus_box">
                
                <ul class="whyus_list">
                    <li><img src="public/assets/images/greyscale/experience.png" alt="" /><h4>Đang cập nhật...</h4></li>
                    <li><img src="public/assets/images/site-icon27.png" alt="" /><h4>Đang cập nhật...</h4></li>
                    <li><img src="public/assets/images/greyscale/update-icon.png" alt="" /><h4>Đang cập nhật...</h4></li>
                    <li><img src="public/assets/images/greyscale/easy-to-install.png" alt="" /><h4>Đang cập nhật...</h4></li>
                    <li><img src="public/assets/images/site-icon23.png" alt="" /><h4>Đang cập nhật...</h4></li>
                    
                </ul>
                
                <ul class="whyus_list last">
                    <li><img src="public/assets/images/site-icon29.png" alt="" /><h4>Đang cập nhật...</h4></li>
                    <li><img src="public/assets/images/greyscale/payment-icon.png" alt="" /><h4>Đang cập nhật...</h4></li>
                    <li><img src="public/assets/images/site-icon22.png" alt="" /><h4>Đang cập nhật...</h4></li>
                    <li><img src="public/assets/images/greyscale/easy-to-use.png" alt="" /><h4>Đang cập nhật...</h4></li>
                    <li><img src="public/assets/images/site-icon24.png" alt="" /><h4>Đang cập nhật...</h4></li>
                </ul>
                
            </div>
        </div><!-- end why choose us-->


      
    
    <div class="people_says_main">
   
    
    <h2>Cập nhật thông tin mới qua Facebook</h2>

    <div class="people_says">
         
<iframe style="margin-left:70px;" src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FDHCNSG%2F&tabs&width=340&height=214&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="214" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

    </div>
            
    </div>
    
    
    </div>

@endsection