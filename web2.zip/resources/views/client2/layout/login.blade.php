@extends('client.master')
@section('content')
<div class="page_title">

	<div class="container">
		<div class="leaft_title"><h1>Đăng nhập</h1></div>
        <div class="reght_pagenation"><a href="/">Trang chủ</a> <i>/</i> Đăng nhập</div>
	</div>
    
</div><!-- end page title -->
<link rel="stylesheet" type="text/css" href="{{ asset('') }}public/assets/css/register.css">

<section class="signup">
    <!-- <img src="images/signup-bg.jpg" alt=""> -->
    <div class="container-2">
        <div class="signup-content">
            <form action="{{route('login')}}" method="POST" id="signup-form" class="signup-form">
            	<input type="hidden" name="_token" value="{{csrf_token()}}">
                <h2 class="form-title">ĐĂNG NHẬP</h2>

				@if(count($errors) > 0)
				@foreach($errors->all() as $err)
					<div class="alert alert-warning">
					    <strong>Cảnh báo!</strong> {{$err}}
				 	 </div>
				@endforeach
				@endif
				
				@if(Session::has('flag'))
				  <div class="alert alert-{{Session::get('flag')}}">
				    <strong>{{Session::get('title')}}</strong> {{Session::get('message')}}
				  </div>
				@endif

                <div class="form-group">
                    <input type="text" class="form-input" name="username" id="username" placeholder="Tên đăng nhập" value="{{old('username')}}" />
                </div>
                <div class="form-group">
                    <input type="password" class="form-input" name="password" id="password" placeholder="Mật khẩu"/>
                    <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" id="submit" class="form-submit" value="Sign up"/>
                </div>
            </form>
            <p class="loginhere">
                Bạn chưa có tài khoản ? <a href="{{ route('register') }}" class="loginhere-link">Đăng ký tại đây</a>
            </p>
        </div>
    </div>
</section>

@endsection