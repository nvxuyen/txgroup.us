@extends('client.master')
@section('content')
<div class="page_title">

    <div class="container">
        <div class="leaft_title"><h1>Danh sách phòng</h1></div>
        <div class="reght_pagenation"><a href="{{route('trang-chu')}}">Trang chủ</a> <i>/</i> <a href="#">Danh sách phòng</a></div>
    </div>
    
</div><!-- end page title -->

<div class="clearfix"></div>


<div class="container">

<style>
.blog_postcontent .image_frame.small {
    width: 40%;
}
.blog_post{
    border: 1px solid #ccc!important
}
.divider_line12 {
    margin: 15px 0 30px 0;
}
li.noactive{
    text-decoration: line-through;
}
fieldset {
    border: 1px solid #9a9a9a;
    background-image: url(images/pebbles.jpg);
    padding: 18px;
    z-index: 1;
    -moz-border-radius: 8px;
    border-radius: 8px;
}
.pagination {
    padding-left: 0;
    margin: 20px 0;
    border-radius: 4px;
}
.pagination>li {
    display: inline;
}
.pagination>li:first-child>a, .pagination>li:first-child>span {
    margin-left: 0;
    border-bottom-left-radius: 4px;
    border-top-left-radius: 4px;
}
.pagination>.disabled>a, .pagination>.disabled>a:focus, .pagination>.disabled>a:hover, .pagination>.disabled>span, .pagination>.disabled>span:focus, .pagination>.disabled>span:hover {
    color: #777;
    background-color: #fff;
    border-color: #ddd;
    cursor: not-allowed;
}
.pagination>.active>a, .pagination>.active>a:focus, .pagination>.active>a:hover, .pagination>.active>span, .pagination>.active>span:focus, .pagination>.active>span:hover {
    z-index: 3;
    color: #fff;
    background-color: #337ab7;
    border-color: #337ab7;
    cursor: default;
}
.pager>li>a, .pagination>li>a {
    border-width: 1px;
    border-color: #d4dfe3;
    color: #2283C5;
    background-color: #FAFAFA;
    margin: 0 -1px 0 0;
    position: relative;
    z-index: auto;
}
.pagination>li>a, .pagination>li>span {
    position: relative;
    float: left;
    padding: 6px 12px;
    line-height: 1.42857143;
    text-decoration: none;
    color: #337ab7;
    background-color: #fff;
    border: 1px solid #ddd;
    margin-left: -1px;
}
</style>
</style>

    <div class="content_left">
        @if(isset($datechoise))
        <h2>Kết quả tìm kiếm cho ngày {{date("d-m-Y",strtotime($datechoise))}}</h2>
        @endif

        @if(isset($count))
        @if($count>0)
        @foreach($filter_room as $f)
            <div class="blog_post"> 
                <div class="blog_postcontent">

                <div class="image_frame small"><a href="#"><img src="public/assets/images/default.png" alt="" /></a></div>
                <div class="post_info_content_small">
                
                
                <h1><a href="#">Phòng: {{$f->name}}</a></h1>

                <div class="clearfix"></div>
                                
                <p>
                    <li>Diện tích: {{$f->area}}</li>
                    <li>Sức chứa: {{$f->capacity}}</li>
                </p>
                <br>
                <br>
                <br>

                <div class="caption sfb tp-caption start" data-x="171" data-y="316" data-speed="300" data-start="2000" data-easing="easeOutExpo" style="float: right;"><a href="book/{{$f->id}}" class="slider_button2">Đặt ngay&nbsp;&nbsp;&nbsp;</a></div>
                </div>
                </div>
            </div><!-- /# end post -->

            <div class="clearfix divider_line12"></div>
        @endforeach

        {{$filter_room->links()}}

        @endif
        @endif
        
    </div><!-- end content left area -->


<!-- right sidebar starts -->
<div class="right_sidebar">
    
    <div class="sidebar_widget">
    
        <div class="sidebar_title"><h3>TÌM PHÒNG TRỐNG</h3></div>
        
            <ul class="sidebar_item_list">
             <form action="room" method="GET">
        
       
                    <fieldset>
                        <legend>Ngày</legend>
                        <input type="date" name="date">
                    </fieldset>

                    <fieldset>
                        <legend>Sức chứa</legend>
                        <input type="text" name="capacity">
                    </fieldset>

                    <fieldset>
                        <legend>Ngày</legend>
                        @foreach($ca as $c)
                            <p><input type="checkbox" name="cbCa[]" value="{{$c->ca}}"> Ca {{$c->ca}} ({{$c->time_start}} - {{$c->time_end}})</p>
                        @endforeach
                    </fieldset>
                    <button type="submit" class="btn-search-room">Tìm phòng trống</button>
                </form>
                        
            </ul>
                
    </div><!-- end section -->
    
</div><!-- end right sidebar -->


</div>
@endsection