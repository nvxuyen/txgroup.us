@extends('client.master')
@section('content')
<div class="page_title">

	<div class="container">
		<div class="leaft_title"><h1>Blog</h1></div>
        <div class="reght_pagenation"><a href="/">Trang chủ</a> <i>/</i> <a href="{{route('blog')}}">Blog</a> <i>/</i> Bài viết</div>
	</div>
    
</div><!-- end page title -->

<div class="clearfix"></div>

<div class="container">

	<div class="content_left">
        	
            <div class="blog_post">	
				<div class="blog_postcontent">
                <a href="#" class="date"><strong>{{\Carbon\Carbon::parse($read->created_at)->format('d')}}</strong><i>Tháng {{\Carbon\Carbon::parse($read->created_at)->format('m')}}</i></a>
				<h1><a href="#">{{$read->title}}</a></h1>
                    <ul class="post_meta_links">
                        <li class="post_comments"><a href="#">0 bình luận</a></li>
                    </ul>
                 
				<div class="post_info_content">
				{!!$read->content!!}
                </div>
				</div>
			</div><!-- /# end post -->
            
            <div class="clearfix divider_line"></div>

            <script type="text/javascript">
			function showPopup(url) {
			var winHeight = 620;
			var winWidth = 520;
			var winTop = 0; //(screen.height / 2) - (winHeight / 2);
			var winLeft = (screen.width / 2) - (winWidth / 2);
			window.open( url, "myWindow", "top=" + winTop + ",left=" + winLeft + ", status = 1, height = " + winHeight + ", width = " + winWidth + ", resizable = yes, scrollbars=yes" )
			}
			</script>
			
            <div class="sharepost">
				<h4>Chia sẻ bài viết</h4>
					<ul>
						<li><a href="javascript:showPopup('https://www.facebook.com/sharer/sharer.php?u=http://ultraviewer.net/vi/60135-cac-cau-hoi-ve-cach-tinh-phi-cua-ultraviewer.html');"><img src="/images/blog/facebook.png" alt="" /></a></li>
						<li><a href="javascript:showPopup('https://twitter.com/share?url=http://ultraviewer.net/vi/60135-cac-cau-hoi-ve-cach-tinh-phi-cua-ultraviewer.html');"><img src="/images/blog/twitter.png" alt="" /></a></li>
						<li><a href="javascript:showPopup('https://plus.google.com/share?url=http://ultraviewer.net/vi/60135-cac-cau-hoi-ve-cach-tinh-phi-cua-ultraviewer.html');"><img src="/images/blog/google-plus.png" alt="" /></a></li>
						<li><a href="javascript:showPopup('https://www.linkedin.com/cws/share?url=http://ultraviewer.net/vi/60135-cac-cau-hoi-ve-cach-tinh-phi-cua-ultraviewer.html');"><img src="/images/blog/linkedin.png" alt="" /></a></li>
					</ul>
				
				</div><!-- end share post links -->
                
                <div class="clearfix"></div>
                
                <h4>Về tác giả</h4>
				<div class="about_author">
				
					<img src="/images/blog/dna-avatar.png" alt="" />
					
					<a href="#" target="_blank"><strong>DucFabulous</strong></a><br />
                   Cuộc đời thật ngắn và chúng ta phải thật nhanh!
				</div><!-- end about author -->
            
            <div class="clearfix mar_top3"></div>
          
      <div class="one_half"> 
         <div class="popular-posts-area">
            <h4>Bài viết mới</h4>
				<ul class="recent_posts_list">
					@foreach($new_post as $new)
					<li>
					  	<span><a href="{{route('blog')}}/readmore/{{$new->id}}"><img src="@if($new->image==NULL) {{"public/assets/images/default.png"}} @else {{$new->image}} @endif" style="width:50px; height: 50px;" alt="{{$new->title}}" /></a></span>
						<a href="{{route('blog')}}/readmore/{{$new->id}}/{{$new->title_ascii}}.html">{{$new->title}}</a>
						 <i>{{\Carbon\Carbon::parse($new->created_at)->format('d/m/Y')}}</i> 
					</li>
					@endforeach
                	
				</ul>
				
			</div>
       </div><!-- end recent posts -->
       
       
       <div class="one_half last"> 
         <div class="popular-posts-area">
            <h4>Bài viết liên quan</h4>
				<ul class="recent_posts_list">
					@foreach($new_related as $rel)
					<li>
					  	<span><a href="{{route('blog')}}/readmore/{{$new->id}}"><img src="@if($new->image==NULL) {{"public/assets/images/default.png"}} @else {{$new->image}} @endif" style="width:50px; height: 50px;" alt="{{$new->title}}" /></a></span>
						<a href="{{route('blog')}}/readmore/{{$new->id}}/{{$new->title_ascii}}.html">{{$new->title}}</a>
						 <i>{{\Carbon\Carbon::parse($new->created_at)->format('d/m/Y')}}</i> 
					</li>
					@endforeach
                
				</ul>
				
			</div>
       </div><!-- end popular posts -->
            
    <div class="clearfix divider_line"></div>


	<div class="mar_top_bottom_lines_small3"></div>
	
	 <div id="comment_place_holder">
		<div class="comment_form" id="comment_form" >
			
			<h4>Viết bình luận <a id="cancelreply" class="cancelreply" style="display:inline; font-size:13px; color:#25aae2 !important; margin-left:20px; visibility: hidden;">(Cancel Reply)</a></h4>

			
			<form name="commentform" action="#commentform" id="commentform" method="post" onsubmit="return validateform()">
					<input type="hidden" name="action" value="comment"/>
					<input type="hidden" name="replytoid" value="0"/>
					<input type="text" name="authorname" id="name" class="comment_input_bg" value=""/>
					<label for="name">Tên bạn*</label>
					
					<input type="text" name="email" id="mail" class="comment_input_bg" value="" />
					<label for="mail">Email*</label>
										
					<textarea name="comment" id="txtcomment" class="comment_textarea_bg" rows="20" cols="7" ></textarea>
					<input type="hidden" id="sec-check" name="sec-check" value="">
					
					<div class="clearfix"></div> 
					<img src="/generatecaptcha.aspx"/>
					<div class="clearfix"></div> 
					<input style="width: 100px;"  type="text" name="captcha" id="captcha" class="comment_input_bg" />
					<input type="hidden" name="captchahash" id="captchahash" value="e88f8acc5d499eb369f0bdd6349b769e">
					<label for="mail">Captcha Code</label>
					
					<div class="clearfix"></div> 
					<br><br>
					<!--begin captcha-->
					<!--
					<div class="clearfix"></div> 
					<form method="post" action="GoogleCaptcha.asp">
					<div class="g-recaptcha" data-sitekey="6LcBMRgTAAAAAKD38zQcF09GbAcfKmE_64avEGJX"></div>
					</form>
					<div class="clearfix"></div> 
					<p></p>
					</br>
					-->
					<!--end captcha-->
					<div class="clearfix"></div> 
					<input name="send" type="submit" value="Gửi bình luận" class="comment_submit"/>
					<p></p>
					<p class="comment_checkbox"><input type="checkbox" name="check" /> Báo cho tôi biết qua email khi có phản hồi</p>
				
				
			</form>
	
			</div><!-- end comment form -->
       </div>    
	
		
			<script>
			//==
			function isInBrowserControl() {
			if (window.external && "MyExternalProperty" in window.external) {
			return true;
			}
			return false;
			}
			$("#sec-check").val(isInBrowserControl());
			//==
			$(".areply").click(function(){
			$("#cancelreply").css("visibility", "visible");
			var parentdiv = $(this).parent().parent().parent();
			//$(parentdiv).append("tett");
			
			try {
			//$("#replytoid").val($(this).attr("commentid"));
			$('input[name="replytoid"]').val($(this).attr("commentid"));
			$("#comment_form").appendTo(parentdiv);
			$("#txtcomment").focus();
			} catch (ex) {
			alert(ex);
			}
			//alert($(a[0]).attr('class'));
			//$(this).append("tet");
			});
		
			$("#cancelreply").click(function(){
			$(this).css("visibility", "hidden");
			$("#replytoid").val(0);
			$("#comment_form").appendTo($("#comment_place_holder"));
			});
			
			function validateform() {
			var x = $("#txtcomment").val();
			if (x == null || x == "") {
			alert("Comment must be filled out");
			return false;
			}
			}
			
			</script>

          <div class="clearfix mar_top2"></div>  
            
        </div><!-- end content left area -->


<!-- right sidebar starts -->
<div class="right_sidebar">
    
    <div class="clearfix mar_top3"></div>
    
	<div class="sidebar_widget">
    	<div class="sidebar_title"><h3>Danh mục</h3></div>
		<ul class="arrows_list1">		
			<li><a  class="active" href="{{route('blog')}}">Tất cả</a></li>
			@foreach($loai_news as $loai)
				<li><a  href="{{route('blog')}}/cat/{{$loai->id}}/{{$loai->name_ascii}}.html">{{$loai->name}}</a></li>
			@endforeach
		</ul>
	</div><!-- end section -->
    
    <div class="clearfix mar_top3"></div>

    
</div><!-- end right sidebar -->


</div>



<div class="clearfix"></div>
@endsection