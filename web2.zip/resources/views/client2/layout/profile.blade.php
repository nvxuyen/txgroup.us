@extends('client.master')
@section('content')
<div class="page_title">

	<div class="container">
		<div class="leaft_title"><h1>Thông tin tài khoản</h1></div>
        <div class="reght_pagenation"><a href="/">Trang chủ</a> <i>/</i> Thông tin tài khoản</div>
	</div>
    
</div><!-- end page title -->
<link rel="stylesheet" type="text/css" href="{{ asset('') }}public/assets/css/register.css">

<section class="signup">
    <!-- <img src="images/signup-bg.jpg" alt=""> -->
    <div class="container-2">
        <div class="signup-content">
            <form action="{{route('profile')}}" method="POST" id="signup-form" class="signup-form">
            	<input type="hidden" name="_token" value="{{csrf_token()}}">
                <h2 class="form-title">THÔNG TIN TÀI KHOẢN</h2>

				@if(count($errors) > 0)
				@foreach($errors->all() as $err)
					<div class="alert alert-warning">
					    <strong>Cảnh báo!</strong> {{$err}}
				 	 </div>
				@endforeach
				@endif
				
				@if(session('thongbao'))
				  <div class="alert alert-success">
				    <strong>Thành công!</strong> {{session('thongbao')}}.
				  </div>
			  	@endif

                <div class="form-group">
                    <input type="text" class="form-input" name="username" id="username" value="{{$user->username}}" disabled>
                </div>
                <div class="form-group">
                    <input type="text" class="form-input" name="fullname" id="fullname" placeholder="Họ và tên" value="{{$user->full_name}}"/>
                </div>
                <div class="form-group">
                    <input type="email" class="form-input" name="email" id="email" placeholder="Địa chỉ Email" value="{{$user->email}}" disabled />
                </div>
                 <div class="form-group">
                    <input type="text" class="form-input" name="phone" id="phone" placeholder="Số điện thoại" value="{{$user->phone}}" disabled />
                </div>
                <div class="form-group">
                    <input type="password" class="form-input" name="password" id="password" placeholder="Mật khẩu"/>
                    <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>
                </div>
                <div class="form-group">
                    <input type="password" class="form-input" name="repassword" id="repassword" placeholder="Nhập lại mật khẩu"/>
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" id="submit" class="form-submit" value="Cập nhật thông tin"/>
                </div>
            </form>
        </div>
    </div>
</section>


@endsection