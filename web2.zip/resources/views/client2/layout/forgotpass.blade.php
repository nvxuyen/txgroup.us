@extends('client.master')
@section('content')
@extends('client.master')
@section('content')
<div class="page_title">

	<div class="container">
		<div class="leaft_title"><h1>Quên mật khẩu?</h1></div>
        <div class="reght_pagenation"><a href="/">Trang chủ</a> <i>/</i> Quên mật khẩu</div>
	</div>
    
</div><!-- end page title -->
<link rel="stylesheet" type="text/css" href="{{ asset('') }}public/assets/css/register.css">

<section class="signup">
    <!-- <img src="images/signup-bg.jpg" alt=""> -->
    <div class="container-2">
        <div class="signup-content">
            <form action="{{route('forgotpassword')}}" method="POST" id="signup-form" class="signup-form">
            	<input type="hidden" name="_token" value="{{csrf_token()}}">
                <h2 class="form-title">QUÊN MẬT KHẨU?</h2>

				@if(count($errors) > 0)
				@foreach($errors->all() as $err)
					<div class="alert alert-warning">
					    <strong>Cảnh báo!</strong> {{$err}}
				 	 </div>
				@endforeach
				@endif
				
				@if(session('thongbao'))
				  <div class="alert alert-success">
				    <strong>Thành công!</strong> {{session('thongbao')}}
				  </div>
				@endif

                @if(session('canhbao'))
                    <div class="alert alert-warning">
                        <strong>Cảnh báo!</strong> {{session('canhbao')}}
                     </div>
                @endif

                <div class="form-group">
                    <input type="email" class="form-input" name="email" id="email" placeholder="Nhập địa chỉ Email" value="{{old('username')}}" />
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" id="submit" class="form-submit" value="Tìm mật khẩu"/>
                </div>
            </form>
        </div>
    </div>
</section>

@endsection