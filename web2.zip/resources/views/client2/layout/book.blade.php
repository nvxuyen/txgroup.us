@extends('client.master')
@section('content')
<div class="page_title">

	<div class="container">
		<div class="leaft_title"><h1>Đặt phòng</h1></div>
        <div class="reght_pagenation"><a href="/">Trang chủ</a> <i>/</i> Đặt phòng</div>
	</div>
    
</div><!-- end page title -->
<link rel="stylesheet" type="text/css" href="{{ asset('') }}public/assets/css/register.css">
	<style type="text/css">
		fieldset {
		    border: 1px solid #9a9a9a;
		    background-image: url(images/pebbles.jpg);
		    padding: 18px;
		    z-index: 1;
		    -moz-border-radius: 8px;
		    border-radius: 8px;
		}
	</style>
<section class="signup">
    <!-- <img src="images/signup-bg.jpg" alt=""> -->
    <div class="container-2">
        <div class="signup-content">
            <form action="{{route('trang-chu')}}/book" method="POST" id="signup-form" class="signup-form">
            	<input type="hidden" name="_token" value="{{csrf_token()}}">
                <h2 class="form-title">ĐẶT PHÒNG</h2>
				<fieldset>
				  <legend>Thông tin phòng:</legend>
					Tên phòng: <b>{{$room->name}}</b><br>
					Sức chứa: <b>{{$room->capacity}}</b><br>
					Diện tích: <b>{{$room->area}}m2</b><br>
				 </fieldset>
				 <br>
				 <input type="hidden" name="id_room" value="{{$room->id}}">
				<fieldset>
				  <legend>Chọn ca</legend>
                <div class="form-group">
                    <select style="width:50%;" name="CaID" id="">
                    	@foreach($ca as $c)
                    	<option value="{{$c->ca}}">Ca {{$c->ca}} ({{$c->time_start}} - {{$c->time_end}})</option>
  						@endforeach
                    </select>
                </div>

				 </fieldset>
				 <br>
               
                <div class="form-group">
                    <input type="submit" name="submit" id="submit" class="form-submit" value="ĐẶT PHÒNG"/>
                </div>
            </form>
        </div>
    </div>
</section>
@endsection