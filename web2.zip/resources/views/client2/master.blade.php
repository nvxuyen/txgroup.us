

<!doctype html>

<!--[if IE 7 ]>    <html lang="en-gb" class="isie ie7 oldie no-js"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en-gb" class="isie ie8 oldie no-js"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en-gb" class="isie ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en-gb" class="no-js"> <!--<![endif]-->


<head>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge" /> 
    <meta charset="utf-8">
    
    <title>{{isset($title) ? $title : ''}}</title>
    <base href="{{ asset('') }}">
    <meta name="description" content="Hệ thống website hỗ trợ đặt mượn phòng của STU." />
    <meta property="og:description" content="Hệ thống website hỗ trợ đặt mượn phòng của STU." />
    <meta property="og:image" content="{{ asset('') }}public/assets/images/home/remote-control-software.png"/>
    <meta name="google-site-verification" content="gf-hX8pGrMNVgDrMnhlUpMN6ueeTLwTYF0CVGlOWPNE" />
    
    
    <!-- Favicon --> 
    <!--<link rel="shortcut icon" href="images/favicon.png" type="image/vnd.microsoft.icon" >-->
    <link href="favicon.png" rel="shortcut icon">
    <!-- this styles only adds some repairs on idevices  -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- Google fonts - witch you want to use - (rest you can just remove) -->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>
    
    <!--[if lt IE 9]>
        <script src="https://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <!-- ######### CSS STYLES ######### -->
    <link rel="stylesheet" href="public/assets/css/reset.css" type="text/css" />
    <link rel="stylesheet" href="public/assets/css/style.css" type="text/css" />
    <!-- responsive devices styles -->
    <link rel="stylesheet" media="screen" href="public/assets/css/responsive-leyouts.css" type="text/css" />
    <!-- jquery jcarousel -->
    <link rel="stylesheet" type="text/css" href="public/assets/js/jcarousel/skin.css" />
    <!-- faqs -->
    <link rel="stylesheet" href="public/assets/js/accordion/accordion.css" type="text/css" media="all">
    <!-- top_menu -->
    <link rel="stylesheet" type="text/css" href="public/assets/js/topmenu/topmenu.css" />
    <script src="public/assets/js/topmenu/topmenu.js"></script>
</head>
<body>
<div class="site_wrapper">
        @include('client.layout.header')
   <div class="top_shadow"></div><!-- end shadow -->
</div><!-- end top -->
<!-- ######### JS FILES ######### -->
<!-- style switcher -->
<script src="public/assets/js/style-switcher/jquery-1.js"></script>
<script src="public/assets/js/style-switcher/styleselector.js"></script>
<!-- main menu -->
<script type="text/javascript" src="public/assets/js/mainmenu/ddsmoothmenu.js"></script>
<script type="text/javascript" src="public/assets/js/mainmenu/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="public/assets/js/mainmenu/selectnav.js"></script>
<!-- get jQuery from the google apis -->
<!--<script type="text/javascript" src="public/assets/js/universal/jquery.js"></script>-->
<script type="text/javascript" src="public/assets/js/universal/jquery191.min.js"></script>
<!-- jquery jcarousel -->
<script type="text/javascript" src="public/assets/js/jcarousel/jquery.jcarousel.min.js"></script>
<!-- REVOLUTION SLIDER -->
<script type="text/javascript" src="public/assets/js/revolutionslider/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
<script type="text/javascript" src="public/assets/js/revolutionslider/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>

<script type="text/javascript" src="public/assets/js/mainmenu/scripts.js"></script>
  <!-- REVOLUTION SLIDER -->
    <link rel="stylesheet" type="text/css" href="public/assets/js/revolutionslider/css/fullwidth.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="public/assets/js/revolutionslider/rs-plugin/css/settings.css" media="screen" />
<!-- Slider
======================================= -->  
@yield('content')
<script>
$(document).ready(function(){
    $('.slider_button1').on('click',function (e) {
        e.preventDefault();

        var target = this.hash;
        var $target = $(target);

        $('html, body').stop().animate({
            'scrollTop': $target.offset().top
        }, 600, 'swing', function () {
            window.location.hash = target;
        });
    });
});
</script> 
<script type="text/javascript">

        var tpj=jQuery;
        tpj.noConflict();

        tpj(document).ready(function() {

        if (tpj.fn.cssOriginal!=undefined)
            tpj.fn.css = tpj.fn.cssOriginal;

            tpj('.fullwidthbanner').revolution(
                {
                    delay:0,
                    startwidth:1000,
                    startheight:425,
                    

                    onHoverStop:"on",                       // Stop Banner Timet at Hover on Slide on/off

                    thumbWidth:100,                         // Thumb With and Height and Amount (only if navigation Tyope set to thumb !)
                    thumbHeight:50,
                    thumbAmount:0,

                    hideThumbs:0,
                    navigationType:"none",              // bullet, thumb, none
                    navigationArrows:"solo",                // nexttobullets, solo (old name verticalcentered), none

                    navigationStyle:"round",                // round,square,navbar,round-old,square-old,navbar-old, or any from the list in the docu (choose between 50+ different item), custom


                    navigationHAlign:"right",               // Vertical Align top,center,bottom
                    navigationVAlign:"bottom",                  // Horizontal Align left,center,right
                    navigationHOffset:50,
                    navigationVOffset:55,

                    soloArrowLeftHalign:"left",
                    soloArrowLeftValign:"center",
                    soloArrowLeftHOffset:0,
                    soloArrowLeftVOffset:0,

                    soloArrowRightHalign:"right",
                    soloArrowRightValign:"center",
                    soloArrowRightHOffset:0,
                    soloArrowRightVOffset:0,

                    touchenabled:"off",                     // Enable Swipe Function : on/off



                    stopAtSlide:0,                          // Stop Timer if Slide "x" has been Reached. If stopAfterLoops set to 0, then it stops already in the first Loop at slide X which defined. -1 means do not stop at any slide. stopAfterLoops has no sinn in this case.
                    stopAfterLoops:0,                       // Stop Timer if All slides has been played "x" times. IT will stop at THe slide which is defined via stopAtSlide:x, if set to -1 slide never stop automatic



                    fullWidth:"on",

                    shadow:0                                //0 = no Shadow, 1,2,3 = 3 Different Art of Shadows -  (No Shadow in Fullwidth Version !)

                });

    });
    </script>
</div>

@include('client.layout.footer')   
</div>
<!-- scroll up -->
<script type="text/javascript">
    $(document).ready(function(){
 
        $(window).scroll(function(){
            if ($(this).scrollTop() > 100) {
                $('.scrollup').fadeIn();
            } else {
                $('.scrollup').fadeOut();
            }
        });
 
        $('.scrollup').click(function(){
            $("html, body").animate({ scrollTop: 0 }, 500);
            return false;
        });
 
    });
</script>
<!-- jquery jcarousel -->
<script type="text/javascript">

    jQuery(document).ready(function() {
            jQuery('#mycarousel').jcarousel();
    });
    
    jQuery(document).ready(function() {
            jQuery('#mycarouseltwo').jcarousel();
    });
</script>
<script type="text/javascript" src="public/assets/js/accordion/custom.js"></script>
</body>
</html>
