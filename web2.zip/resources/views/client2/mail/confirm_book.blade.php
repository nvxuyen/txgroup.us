<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#dcf0f8" style="margin:0;padding:0;background-color:#f2f2f2;width:100%!important;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px">
    <tbody>
    <tr>
        <td align="center" valign="top" style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal">

            
            <table border="0" cellpadding="0" cellspacing="0" width="600" style="margin-top:15px">
                <tbody>
                <tr>
                    <td align="center" valign="bottom" id="m_-4918830871326323592headerImage">
                        <table width="100%" cellpadding="0" cellspacing="0" style="border-bottom:3px solid #00b7f1;padding-bottom:10px;background-color:#fff">
                            <tbody>
                            <tr>
                                <td valign="top" bgcolor="#FFFFFF" width="100%" style="padding:0">
                                    <strong><a style="color:#00a3dd;text-decoration:none;font-size:36px" href="{{route('trang-chu')}}" target="_blank">TXGroup.us</a></strong><br>

                                    
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>


                
                <tr style="background:#fff">
                    <td align="left" width="600" height="auto" style="padding:15px">
                        <table>
                            <tbody>
                            <tr>

                                <td>
                                    <h1 style="font-size:17px;font-weight:bold;color:#444;padding:0 0 5px 0;margin:0">
                                        Cảm ơn
                                        {{$info->full_name}}
                                        đã đặt mượn phòng tại TXGroup,</h1>

                                </td>


                            </tr>

                            <tr>
                                <td>
                                    <h2 style="text-align:left;margin:10px 0;border-bottom:1px solid #ddd;padding-bottom:5px;font-size:13px;color:#02acea">
                                        CHI TIẾT PHÒNG MÃ #{{$code}}</h2>

                                    <table cellspacing="0" cellpadding="0" border="0" width="100%" style="background:#f5f5f5">
                                        <thead>
                                        <tr>
                                            <th align="left" bgcolor="#02acea" style="padding:6px 9px;color:#fff;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:14px">Tên phòng</th>
                                            <th align="left" bgcolor="#02acea" style="padding:6px 9px;color:#fff;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:14px"> Ca</th>
                                            <th align="left" bgcolor="#02acea" style="padding:6px 9px;color:#fff;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:14px">Thời gian bắt đầu</th>
                                            <th align="left" bgcolor="#02acea" style="padding:6px 9px;color:#fff;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:14px">Thời gian kết thúc</th>
                                            <th align="right" bgcolor="#02acea" style="padding:6px 9px;color:#fff;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:14px">Ngày đặt</th>
                                        </tr>
                                        </thead>
                                        <tbody bgcolor="#eee" style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px">
                                                                                <tr>
                                            <td align="left" valign="top" style="padding:3px 9px">
                                                <span class="m_-4918830871326323592name">{{$info->name}}</span><br>
                                                                                            </td>
                                            <td align="left" valign="top" style="padding:3px 9px"><span>{{$info->ca}}</span></td>
                                            <td align="left" valign="top" style="padding:3px 9px">{{$info->time_start}}</td>
                                            <td align="left" valign="top" style="padding:3px 9px"><span>{{$info->time_end}}</span></td>
                                            <td align="right" valign="top" style="padding:3px 9px"><span>{{date('d-m-Y',strtotime($info->date))}}</span></td>
                                        </tr>
                                        </tbody>
     
                                    </table>
                                    <div style="margin:auto">
                                        <a href="{{route('room-history')}}" style="display:inline-block;text-decoration:none;background-color:#00b7f1!important;margin-right:30px;text-align:center;border-radius:3px;color:#fff;padding:5px 10px;font-size:12px;font-weight:bold;margin-left:35%;margin-top:5px" target="_blank">Xem trạng thái phòng tại TXGroup.us</a></div>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <br>

                                    <p style="font-family:Arial,Helvetica,sans-serif;font-size:12px;margin:0;padding:0;line-height:18px;color:#444;font-weight:bold">
                                        Cảm ơn.<br>

                                    </p>

                                    <p style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal;text-align:right">

                                        <strong><a style="color:#00a3dd;text-decoration:none;font-size:14px" href="{{route('trang-chu')}}" target="_blank">TXGroup.us</a></strong><br>
                                    </p>
                                </td>
                            </tr>


                            </tbody>
                        </table>
                    </td>
                </tr>


                </tbody>

            </table>


        </td>

    </tr>

    <tr>
        <td align="center">
            <table width="600">
                <tbody><tr>
                    <td>
                        <p style="font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:18px;color:#4b8da5;padding:10px 0;margin:0px;font-weight:normal" align="left">
 
                            <b>Trường ĐHCNSG:</b> 180 Cao Lỗ, Quận 8, TP.HCM, Việt Nam
                        </p>
                    </td>
                </tr>
            </tbody></table>
        </td>
    </tr>
    </tbody>
</table>