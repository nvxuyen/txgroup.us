	<div class="news-menu list-group">
		<span class="list-group-item active">Danh mục blog</span>
		<ul class="nav sidebar" id="menu-blog">

			<li class="items has-sub  first">
				<a href="/">
					<span class="lbl">LK ráp máy</span>
					<span data-toggle="collapse" data-parent="#cssmenu" href="#sub-item-1" class="sign">
						<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
					</span>
				</a>
				<ul class="nav children collapse" id="sub-item-1">
					
					
					<li class="first">
						<a href="/collections/sieu-khuyen-mai" title="SIÊU KHUYẾN MÃI">
							<span>SIÊU KHUYẾN MÃI</span>
						</a>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/may-bo-tan-doanh-1" title="Máy bộ Tân Doanh">
							<span>Máy bộ Tân Doanh</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/may-bo-9900k" title="Máy bộ 9900k">
									<span>Máy bộ 9900k</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/may-bo-gaming" title="Máy bộ gaming">
									<span>Máy bộ gaming</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/may-bo-van-phong" title="Máy bộ văn phòng">
									<span>Máy bộ văn phòng</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/may-bo-amd" title="MÁY BỘ AMD">
									<span>MÁY BỘ AMD</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/cpu-bo-vi-xu-ly-1" title="CPU- Bộ vi xử lí">
							<span>CPU- Bộ vi xử lí</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/cpu-amd" title="Amd Ryzen">
									<span>Amd Ryzen</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/intel-socket-1151v2-gen9" title="Intel Coffee Lake 1151v2 Gen9">
									<span>Intel Coffee Lake 1151v2 Gen9</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/cpu-intel-coffee-lake-socket-1151v2" title="Intel Coffee Lake 1151v2 Gen8">
									<span>Intel Coffee Lake 1151v2 Gen8</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/cpu-intel-socket-1151" title="Intel Socket 1151 Gen6-7">
									<span>Intel Socket 1151 Gen6-7</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/cpu-intel-socket-2066" title="Intel Socket 2066 for X299">
									<span>Intel Socket 2066 for X299</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/cpu-intel-socket-2011-v3-v4" title="Intel Socket 2011 for X99">
									<span>Intel Socket 2011 for X99</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/intel-xeon" title="Intel Xeon">
									<span>Intel Xeon</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/mainboard-intel" title="Mainboard Intel">
							<span>Mainboard Intel</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="odd">
								<a href="/collections/intel-b365-coffee-lake-for-gen8-9" title="Intel B365 Coffee Lake for Gen8-9">
									<span>Intel B365 Coffee Lake for Gen8-9</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/intel-z390-socket-1151v2" title="Intel Z390 Socket 1151v2 Coffee Lake">
									<span>Intel Z390 Socket 1151v2 Coffee Lake</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mainboard-intel-socket-1151v2-coffee-lake" title="Intel Socket 1151v2 Coffee Lake">
									<span>Intel Socket 1151v2 Coffee Lake</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mainboard-intel-soket-1151-kabylake" title="Intel Soket 1151 Kabylake">
									<span>Intel Soket 1151 Kabylake</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mainboard-intel-x299-socket-2066" title="Intel X299 Socket 2066">
									<span>Intel X299 Socket 2066</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mainboard-intel-x99-socket-2011v3" title="Intel X99 Socket 2011v3">
									<span>Intel X99 Socket 2011v3</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mainboard-intel-socket-1150-haswell" title="Intel Socket 1150 Haswell">
									<span>Intel Socket 1150 Haswell</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mainboard-server-ws-1" title="Mainboard Server WS">
									<span>Mainboard Server WS</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/mainboard-amd" title="Mainboard AMD">
							<span>Mainboard AMD</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="odd">
								<a href="/collections/mainboard-amd-asus" title="Mainboard Amd ASUS">
									<span>Mainboard Amd ASUS</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mainboard-amd-asrock" title="Mainboard Amd ASROCK">
									<span>Mainboard Amd ASROCK</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mainboard-amd-gigabyte" title="Mainboard Amd GIGABYTE">
									<span>Mainboard Amd GIGABYTE</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mainboard-amd-msi" title="Mainboard Amd MSI">
									<span>Mainboard Amd MSI</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/x470-ryzen2" title="X470 RYZEN2">
									<span>X470 RYZEN2</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/x399-for-amd-tr4-cpu" title="X399 FOR AMD TR4 CPU">
									<span>X399 FOR AMD TR4 CPU</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/b450-socket-am4" title="B450 SOCKET AM4">
									<span>B450 SOCKET AM4</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/ram-bo-nho-trong-1" title="RAM- Bộ nhớ trong">
							<span>RAM- Bộ nhớ trong</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/ddr4-for-desktop" title="DDR4 for Desktop">
									<span>DDR4 for Desktop</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/ram-ddr3-for-desktop" title="Ram DDR3 for Desktop">
									<span>Ram DDR3 for Desktop</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/ram-for-laptop" title="RAM for Laptop">
									<span>RAM for Laptop</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/ram-for-server" title="Ram for Server">
									<span>Ram for Server</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/gigabyte-ddr4" title="GIGABYTE DDR4">
									<span>GIGABYTE DDR4</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/case-thung-may" title="CASE - Thùng máy">
							<span>CASE - Thùng máy</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="odd">
								<a href="/collections/case-infinity" title="Case Infinity">
									<span>Case Infinity</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/case-phanteks" title="Case Phanteks">
									<span>Case Phanteks</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/dark-flash" title="DARK FLASH">
									<span>DARK FLASH</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/case-cougar" title="Case Cougar">
									<span>Case Cougar</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/case-cooler-master" title="Case Cooler Master">
									<span>Case Cooler Master</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/case-in-win" title="Case In-win">
									<span>Case In-win</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/case-nzxt" title="NZXT">
									<span>NZXT</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/case-corsair" title="Case Corsair">
									<span>Case Corsair</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/case-id-cooling" title="Case  ID Cooling">
									<span>Case  ID Cooling</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/case-zalman" title="Case Zalman">
									<span>Case Zalman</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/case-thuong-hieu-khac" title="Case Thương hiệu khác">
									<span>Case Thương hiệu khác</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/case-phu-kien-cho-case" title="Case - Phụ kiện cho Case">
									<span>Case - Phụ kiện cho Case</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/aorus-gaming-case" title="AORUS GAMING CASE">
									<span>AORUS GAMING CASE</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/psu-bo-nguon" title="PSU - Bộ nguồn">
							<span>PSU - Bộ nguồn</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/psu-infinity" title="PSU Infinity">
									<span>PSU Infinity</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/psu-andyson" title="PSU Andyson">
									<span>PSU Andyson</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/psu-corsair" title="PSU Corsair">
									<span>PSU Corsair</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/psu-cooler-master" title="PSU Cooler Master">
									<span>PSU Cooler Master</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/psu-seasonic" title="PSU Seasonic">
									<span>PSU Seasonic</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/psu-antec" title="PSU Antec">
									<span>PSU Antec</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/nguon-fsp" title="PSU FSP">
									<span>PSU FSP</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/psu-in-win" title="PSU IN-WIN">
									<span>PSU IN-WIN</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/psu-cay-tien-ao" title="PSU CÀY TIỀN ẢO">
									<span>PSU CÀY TIỀN ẢO</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/psu-cougar-bo-nguon-thuong-hieu-duc" title="PSU Cougar - Bộ nguồn thương hiệu Đức">
									<span>PSU Cougar - Bộ nguồn thương hiệu Đức</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/phu-kien-cho-nguon" title="Phụ kiện cho nguồn">
									<span>Phụ kiện cho nguồn</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/day-nguon-boc-luoi" title="Dây nguồn bọc lưới">
									<span>Dây nguồn bọc lưới</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/psu-gigabyte" title="PSU Gigabyte">
									<span>PSU Gigabyte</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/psu-asus" title="PSU ASUS">
									<span>PSU ASUS</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/ssd-o-the-ran" title="SSD - Ổ thể rắn">
							<span>SSD - Ổ thể rắn</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/samsung-ssd" title="Samsung SSD">
									<span>Samsung SSD</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/wd-ssd" title="WD SSD">
									<span>WD SSD</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/plextor-ssd" title="Plextor SSD">
									<span>Plextor SSD</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/ssd-m-2" title="SSD M.2">
									<span>SSD M.2</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/ssd-sata-3" title="SSD Sata 3">
									<span>SSD Sata 3</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/120-128gb" title="120-128GB">
									<span>120-128GB</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/240-250-256gb" title="240-250-256GB">
									<span>240-250-256GB</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/480-500-512-1tb" title="480-500-512-1TB">
									<span>480-500-512-1TB</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/ssd-khac" title="SSD Khác">
									<span>SSD Khác</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/hdd-o-cung-co-gan-trong" title="HDD - Ổ cứng cơ gắn trong">
							<span>HDD - Ổ cứng cơ gắn trong</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="odd">
								<a href="/collections/western-digital-hdd-3-5" title="Western Hdd">
									<span>Western Hdd</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/seagate-hdd-3-5" title="Seagate Hdd">
									<span>Seagate Hdd</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/seagate-skyhawk-for-camera" title="Seagate Skyhawk for Camera">
									<span>Seagate Skyhawk for Camera</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/seagate-ironwolf-for-nas" title="Seagate IronWolf for Nas">
									<span>Seagate IronWolf for Nas</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/hdd-3-5-toshiba" title="Toshiba Hdd">
									<span>Toshiba Hdd</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/hdd-2-5" title="HDD 2.5" "="">
									<span>HDD 2.5"</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/hdd-3-5" title="HDD 3.5" "="">
									<span>HDD 3.5"</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/odd-o-dia-quang" title="ODD - Ổ đĩa quang">
							<span>ODD - Ổ đĩa quang</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/odd-dvd-rw" title="ODD DVD RW">
									<span>ODD DVD RW</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/odd-dvd-rom" title="ODD DVD rom">
									<span>ODD DVD rom</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/vga-card-do-hoa" title="VGA - Card đồ họa">
							<span>VGA - Card đồ họa</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/vga-nvidia-quadro" title="Nvidia Quadro">
									<span>Nvidia Quadro</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/gtx1660ti-6gb" title="GTX1660ti 6GB">
									<span>GTX1660ti 6GB</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/2080-ti" title="RTX 2080 Ti 11GB">
									<span>RTX 2080 Ti 11GB</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/2080" title="RTX 2080 8GB">
									<span>RTX 2080 8GB</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/rtx-2070" title="RTX 2070 8GB">
									<span>RTX 2070 8GB</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/rtx-2060-6gb" title="RTX 2060 6GB">
									<span>RTX 2060 6GB</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/gtx-1070-1070ti-1080ti" title="GTX 1070-1070ti-1080ti">
									<span>GTX 1070-1070ti-1080ti</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/nvidia-gtx-1060-6gb" title="GTX 1060">
									<span>GTX 1060</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/nvidia-gtx-1050ti-4gb" title="GTX 1050Ti 4GB">
									<span>GTX 1050Ti 4GB</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/nvidia-gtx-1050-2gb" title="GTX 1050 2GB-3GB">
									<span>GTX 1050 2GB-3GB</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/nvidia-gt-1030" title="GT 1030 2GB">
									<span>GT 1030 2GB</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/amd-vga" title="AMD VGA">
									<span>AMD VGA</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/vga-khac" title="VGA KHÁC">
									<span>VGA KHÁC</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/lcd-man-hinh-vi-tinh" title="LCD - Màn hình vi tính">
							<span>LCD - Màn hình vi tính</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="odd">
								<a href="/collections/lcd-gaming-75hz-1-44hz-240hz" title="LCD GAMING 75Hz -1 44Hz - 240Hz">
									<span>LCD GAMING 75Hz -1 44Hz - 240Hz</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/lcd-dell" title="LCD Dell">
									<span>LCD Dell</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/lcd-lg" title="LCD LG">
									<span>LCD LG</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/lcd-asus" title="LCD Asus">
									<span>LCD Asus</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/lcd-alienware" title="LCD Alienware">
									<span>LCD Alienware</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/lcd-hp" title="LCD HP">
									<span>LCD HP</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/lcd-aoc" title="LCD AOC">
									<span>LCD AOC</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/lcd-samsung" title="LCD Samsung">
									<span>LCD Samsung</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/lcd-msi" title="LCD MSI">
									<span>LCD MSI</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/lcd-infinity" title="LCD Infinity">
									<span>LCD Infinity</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/lcd-benq" title="LCD BenQ">
									<span>LCD BenQ</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/lcd-crossover" title="LCD CrossOver">
									<span>LCD CrossOver</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/lcd-philips" title="LCD Philips">
									<span>LCD Philips</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/gigabyte-aorus" title="GIGABYTE AORUS">
									<span>GIGABYTE AORUS</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="">
						<a href="/collections/sound-card-card-am-thanh" title="Sound Card - Card âm thanh">
							<span>Sound Card - Card âm thanh</span>
						</a>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/laptop" title="Laptop">
							<span>Laptop</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="odd">
								<a href="/collections/msi-gaming-laptop" title="MSI Gaming Laptop">
									<span>MSI Gaming Laptop</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/hp-laptop" title="HP Laptop">
									<span>HP Laptop</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/dell-laptop" title="Dell Laptop">
									<span>Dell Laptop</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="last">
						<a href="/collections/may-bo-cu" title="Máy bộ cũ">
							<span>Máy bộ cũ</span>
						</a>
					</li>
					
					
				</ul>
			</li>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			<li class="item has-sub  ">
				<a href="/collections/gaming-gear">
					<span class="lbl">Gaming Gear</span>
					<span data-toggle="collapse" data-parent="#cssmenu" href="#sub-item-2" class="sign">
						<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
					</span>
				</a>
				<ul class="nav children collapse" id="sub-item-2">
					
					
					<li class="has-sub first">
						<a href="/collections/mouse-chuot-1" title="Mouse -  Chuột">
							<span>Mouse -  Chuột</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/mouse-cougar" title="Mouse Cougar">
									<span>Mouse Cougar</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-infinity" title="Mouse Infinity">
									<span>Mouse Infinity</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mouse-asus" title="Mouse Asus">
									<span>Mouse Asus</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-foxxray" title="Mouse  FoxXray">
									<span>Mouse  FoxXray</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mouse-sharkoon" title="Mouse Sharkoon">
									<span>Mouse Sharkoon</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-zalman" title="Mouse Zalman">
									<span>Mouse Zalman</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mouse-razer" title="Mouse Razer">
									<span>Mouse Razer</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-zowie-usa" title="Mouse Zowie USA">
									<span>Mouse Zowie USA</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mouse-intopic" title="Mouse Intopic">
									<span>Mouse Intopic</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-logitech" title="Mouse Logitech">
									<span>Mouse Logitech</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mouse-corsair" title="Mouse  Corsair">
									<span>Mouse  Corsair</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-thuong-hieu-khac" title="Mouse thương hiệu khác">
									<span>Mouse thương hiệu khác</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mouse-steelseries" title="Mouse SteelSeries">
									<span>Mouse SteelSeries</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-mitsumi" title="Mouse Mitsumi">
									<span>Mouse Mitsumi</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/mouse-pads-lot-chuot" title="Mousepad- Lót chuột">
							<span>Mousepad- Lót chuột</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/mouse-pads-infinity" title="Mouse Pads Infinity">
									<span>Mouse Pads Infinity</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-pads-cougar" title="Mouse Pads Cougar">
									<span>Mouse Pads Cougar</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mouse-pads-asus" title="Mouse Pads Asus">
									<span>Mouse Pads Asus</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-pad-sharkoon" title="Mouse pad Sharkoon">
									<span>Mouse pad Sharkoon</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mouse-pad-zalman" title="Mouse pad Zalman">
									<span>Mouse pad Zalman</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-pad-in-win" title="Mouse pad In-Win">
									<span>Mouse pad In-Win</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mouse-pads-gskill" title="Mouse Pads Gskill">
									<span>Mouse Pads Gskill</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-pad-corepad" title="Mouse pad Corepad">
									<span>Mouse pad Corepad</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mouse-pad-roccat" title="Mouse pad Roccat">
									<span>Mouse pad Roccat</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-pad-razer" title="Mouse pad Razer">
									<span>Mouse pad Razer</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mouse-pad-zowie-usa" title="Mouse pad Zowie USA">
									<span>Mouse pad Zowie USA</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-pad-foxxray" title="Mouse pad FoxXray">
									<span>Mouse pad FoxXray</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/mouse-pad-steelseries" title="Mouse pad SteelSeries">
									<span>Mouse pad SteelSeries</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/mouse-pad-corsair" title="Mouse pad Corsair">
									<span>Mouse pad Corsair</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="">
						<a href="/collections/mouse-feet" title="MOUSE FEET">
							<span>MOUSE FEET</span>
						</a>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/keyboard-ban-phim-1" title="Keyboard- Bàn phím">
							<span>Keyboard- Bàn phím</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/keyboard-cougar" title="Keyboard Cougar">
									<span>Keyboard Cougar</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/keyboard-infinity" title="Keyboard infinity">
									<span>Keyboard infinity</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/keyboard-asus" title="Keyboard Asus">
									<span>Keyboard Asus</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/keyboard-foxxray" title="Keyboard FoxXray">
									<span>Keyboard FoxXray</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/keyboard-cherry-germany" title="Keyboard Cherry - Germany">
									<span>Keyboard Cherry - Germany</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/keyboard-zalman" title="Keyboard Zalman">
									<span>Keyboard Zalman</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/keyboard-intopic" title="Keyboard Intopic">
									<span>Keyboard Intopic</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/keyboard-r8" title="Keyboard R8">
									<span>Keyboard R8</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/keyboard-zowie-usa" title="Keyboard Zowie USA">
									<span>Keyboard Zowie USA</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/keyboard-steelseries" title="Keyboard SteelSeries">
									<span>Keyboard SteelSeries</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/keyboard-sharkoon" title="Keyboard Sharkoon">
									<span>Keyboard Sharkoon</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/keyboard-gskill" title="Keyboard Gskill">
									<span>Keyboard Gskill</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/keyboard-cm-storm" title="Keyboard CM Storm">
									<span>Keyboard CM Storm</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/keyboard-corsair" title="Keyboard Corsair">
									<span>Keyboard Corsair</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/keyboard-razer" title="Keyboard Razer">
									<span>Keyboard Razer</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/keyboard-logitech" title="Keyboard Logitech">
									<span>Keyboard Logitech</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/keycaps" title="Keycaps">
							<span>Keycaps</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/keycaps-pbt" title="Keycaps PBT">
									<span>Keycaps PBT</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/keycaps-abs" title="Keycaps ABS">
									<span>Keycaps ABS</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="">
						<a href="/collections/combo-keyboard-mouse" title="Combo phím chuột">
							<span>Combo phím chuột</span>
						</a>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/tai-nghe-1" title="Tai nghe">
							<span>Tai nghe</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/tai-nghe-cougar" title="Tai nghe Cougar">
									<span>Tai nghe Cougar</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tai-nghe-asus" title="Tai nghe Asus">
									<span>Tai nghe Asus</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tai-nghe-infinity" title="Tai nghe Infinity">
									<span>Tai nghe Infinity</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tai-nghe-zalman" title="Tai nghe Zalman">
									<span>Tai nghe Zalman</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tai-nghe-foxxray" title="Tai nghe FoxXray">
									<span>Tai nghe FoxXray</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tai-nghe-sharkoon" title="Tai nghe Sharkoon">
									<span>Tai nghe Sharkoon</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tai-nghe-roccat" title="Tai nghe Roccat">
									<span>Tai nghe Roccat</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tai-nghe-sony" title="Tai nghe Sony">
									<span>Tai nghe Sony</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tai-nghe-corsair" title="Tai nghe Corsair">
									<span>Tai nghe Corsair</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tai-nghe-kingston" title="Tai nghe Kingston">
									<span>Tai nghe Kingston</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tai-nghe-razer" title="Tai nghe Razer">
									<span>Tai nghe Razer</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tai-nghe-steel-series" title="Tai nghe Steel Series">
									<span>Tai nghe Steel Series</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tai-nghe-marvo" title="Tai nghe Marvo">
									<span>Tai nghe Marvo</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="">
						<a href="/collections/speaker-loa-vi-tinh" title="Speaker- Loa vi tính">
							<span>Speaker- Loa vi tính</span>
						</a>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/ghe-gaming" title="Ghế Gaming">
							<span>Ghế Gaming</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="odd">
								<a href="/collections/ghe-gaming-ak-racing" title="Ghế gaming Ak Racing">
									<span>Ghế gaming Ak Racing</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/ghe-gaming-dx-racer" title="Ghế gaming DX Racer">
									<span>Ghế gaming DX Racer</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/ghe-gaming-cougar" title="Ghế gaming Cougar">
									<span>Ghế gaming Cougar</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/ghe-gaming-anda-seat" title="Ghế gaming Anda Seat">
									<span>Ghế gaming Anda Seat</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="">
						<a href="/collections/mat-kinh-gaming" title="Mắt kính Gaming">
							<span>Mắt kính Gaming</span>
						</a>
					</li>
					
					
					
					<li class="">
						<a href="/collections/linh-kien-khac-game-pad-tay-cam-choi-game" title="Game Pad - Tay cầm chơi game">
							<span>Game Pad - Tay cầm chơi game</span>
						</a>
					</li>
					
					
					
					<li class="">
						<a href="/collections/webcam-pc-camera" title="Webcam - PC camera">
							<span>Webcam - PC camera</span>
						</a>
					</li>
					
					
					
					<li class="last">
						<a href="/collections/linh-kien-khac-vo-lang-dua-xe-can-lai" title="Vô Lăng Đua Xe - Cần Lái">
							<span>Vô Lăng Đua Xe - Cần Lái</span>
						</a>
					</li>
					
					
				</ul>
			</li>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			<li class="item has-sub  ">
				<a href="/">
					<span class="lbl">LK ngoại vi</span>
					<span data-toggle="collapse" data-parent="#cssmenu" href="#sub-item-3" class="sign">
						<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
					</span>
				</a>
				<ul class="nav children collapse" id="sub-item-3">
					
					
					<li class="first">
						<a href="/collections/usb" title="USB Stick">
							<span>USB Stick</span>
						</a>
					</li>
					
					
					
					<li class="">
						<a href="/collections/hub-usb-bo-chia-cong-usb" title="Hub Usb- Bộ chia cổng Usb">
							<span>Hub Usb- Bộ chia cổng Usb</span>
						</a>
					</li>
					
					
					
					<li class="">
						<a href="/collections/the-nho" title="Thẻ nhớ">
							<span>Thẻ nhớ</span>
						</a>
					</li>
					
					
					
					<li class="">
						<a href="/collections/o-cung-gan-ngoai-1" title="HDD và SSD gắn ngoài">
							<span>HDD và SSD gắn ngoài</span>
						</a>
					</li>
					
					
					
					<li class="">
						<a href="/collections/box-va-dock-hdd" title="Box và Dock HDD">
							<span>Box và Dock HDD</span>
						</a>
					</li>
					
					
					
					<li class="">
						<a href="/collections/ups" title="UPS - Bộ lưu điện">
							<span>UPS - Bộ lưu điện</span>
						</a>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/thiet-bi-mang" title="Network - Thiết bị mạng">
							<span>Network - Thiết bị mạng</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="odd">
								<a href="/collections/thiet-bi-mang-net-cam" title="Net Cam">
									<span>Net Cam</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/thiet-bi-mang-router-vpn" title="Router - VPN">
									<span>Router - VPN</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/thiet-bi-mang-adapter-wireless" title="Card wifi">
									<span>Card wifi</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/thiet-bi-mang-switch" title="Switch">
									<span>Switch</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/thiet-bi-mang-cable-mang" title="Cable Mạng">
									<span>Cable Mạng</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="">
						<a href="/collections/linh-kien-khac-pin-du-phong-infinity" title="Pin Dự Phòng Infinity">
							<span>Pin Dự Phòng Infinity</span>
						</a>
					</li>
					
					
					
					<li class="">
						<a href="/collections/linh-kien-khac-cac-loai-cable-noi" title="Cables- Cáp các loại">
							<span>Cables- Cáp các loại</span>
						</a>
					</li>
					
					
					
					<li class="has-sub last">
						<a href="/collections/camera-hanh-trinh" title="Camera hành trình">
							<span>Camera hành trình</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/gopro-accessories" title="GoPro &amp; Accessories">
									<span>GoPro &amp; Accessories</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
				</ul>
			</li>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			<li class="item has-sub  ">
				<a href="/">
					<span class="lbl">Tản nhiệt</span>
					<span data-toggle="collapse" data-parent="#cssmenu" href="#sub-item-4" class="sign">
						<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
					</span>
				</a>
				<ul class="nav children collapse" id="sub-item-4">
					
					
					<li class="has-sub first">
						<a href="/collections/tan-nhiet" title="Tản khí - Air Cooling">
							<span>Tản khí - Air Cooling</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="odd">
								<a href="/collections/tan-nhiet-cho-cpu" title="Tản nhiệt cho CPU">
									<span>Tản nhiệt cho CPU</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tan-nhiet-cho-vga" title="Tản nhiệt cho VGA">
									<span>Tản nhiệt cho VGA</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tan-nhiet-cho-hdd" title="Tản nhiệt cho HDD">
									<span>Tản nhiệt cho HDD</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tan-nhiet-cho-laptop" title="Tản nhiệt cho Laptop">
									<span>Tản nhiệt cho Laptop</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/tan-nhiet-nuoc-aio" title="Tản nước trọn gói - AIO">
							<span>Tản nước trọn gói - AIO</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="odd">
								<a href="/collections/aio-infinity" title="AIO Infinity">
									<span>AIO Infinity</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tan-nhiet-nuoc-aio-id-cooling" title="AIO ID Cooling">
									<span>AIO ID Cooling</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/cooler-master" title="AIO Cooler Master">
									<span>AIO Cooler Master</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tan-nhiet-nuoc-aio-corsair" title="AIO Corsair">
									<span>AIO Corsair</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/nzxt-1" title="AIO NZXT">
									<span>AIO NZXT</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tan-nhiet-nuoc-aio-zalman" title="AIO Zalman">
									<span>AIO Zalman</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tan-nhiet-nuoc-aio-xspc" title="AIO XSPC">
									<span>AIO XSPC</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/tan-nhiet-nuoc-tuy-chon" title="Tản nước tùy chọn - Custom">
							<span>Tản nước tùy chọn - Custom</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-cpu-blocks" title="CPU Blocks">
									<span>CPU Blocks</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-mainboard-chipset-blocks" title="Mainboard/Chipset Blocks">
									<span>Mainboard/Chipset Blocks</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-vga-blocks" title="VGA Blocks">
									<span>VGA Blocks</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-ram-blocks" title="Ram Blocks">
									<span>Ram Blocks</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-reservoir-accessories" title="Reservoir &amp; Accessories">
									<span>Reservoir &amp; Accessories</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-pump-accessories" title="Pump &amp; Accessories">
									<span>Pump &amp; Accessories</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-radiators-accessories" title="Radiators &amp; Accessories">
									<span>Radiators &amp; Accessories</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-fan-for-radiator" title="Fan for Radiator">
									<span>Fan for Radiator</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-fittings-accessories" title="Fittings &amp; Accessories">
									<span>Fittings &amp; Accessories</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-tube-accessories" title="Tube &amp; Accessories">
									<span>Tube &amp; Accessories</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-petg-hard-tube-accessories" title="PETG Hard Tube &amp; Accessories">
									<span>PETG Hard Tube &amp; Accessories</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-coolant" title="Coolant">
									<span>Coolant</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/tan-nhiet-nuoc-tuy-chon-linh-kien-khac" title="Linh kiện khác">
									<span>Linh kiện khác</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/bo-tan-nhiet-nuoc-custom" title="Bộ tản nhiệt nước custom">
									<span>Bộ tản nhiệt nước custom</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/quat-tan-nhiet-case" title="Quạt Tản nhiệt Case">
							<span>Quạt Tản nhiệt Case</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/quat-tan-nhiet-case-infinity" title="Quạt Case Infinity">
									<span>Quạt Case Infinity</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/quat-tan-nhiet-case-deepcool" title="Quạt Tản nhiệt Case Deepcool">
									<span>Quạt Tản nhiệt Case Deepcool</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/quat-tan-nhiet-case-corsair" title="Quạt Case Corsair">
									<span>Quạt Case Corsair</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/quat-tan-nhiet-case-zalman" title="Quạt Case Zalman">
									<span>Quạt Case Zalman</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/quat-tan-nhiet-case-phanteks" title="Quạt Case Phanteks">
									<span>Quạt Case Phanteks</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/quat-tan-nhiet-in-win" title="Quạt Case In-win">
									<span>Quạt Case In-win</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/quat-case-nzxt" title="Quạt Case NZXT">
									<span>Quạt Case NZXT</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="">
						<a href="/collections/kem-tan-nhiet-thermal-pad" title="Kem Tản Nhiệt-Thermal Pad">
							<span>Kem Tản Nhiệt-Thermal Pad</span>
						</a>
					</li>
					
					
					
					<li class="last">
						<a href="/collections/fan-hub-chia-dau-cam-fan" title="Fan hub - chia đầu cắm fan">
							<span>Fan hub - chia đầu cắm fan</span>
						</a>
					</li>
					
					
				</ul>
			</li>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			<li class="item has-sub  ">
				<a href="/">
					<span class="lbl">Sản phẩm khác</span>
					<span data-toggle="collapse" data-parent="#cssmenu" href="#sub-item-5" class="sign">
						<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
					</span>
				</a>
				<ul class="nav children collapse" id="sub-item-5">
					
					
					<li class="has-sub first">
						<a href="/collections/dien-thoai-di-dong" title="Điện Thoại Di Động">
							<span>Điện Thoại Di Động</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="odd">
								<a href="/collections/dien-thoai-di-dong-xiaomi-chinh-hang" title="Xiaomi chính hãng">
									<span>Xiaomi chính hãng</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/dien-thoai-di-dong-elari-russia" title="Elari Russia">
									<span>Elari Russia</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="">
						<a href="/collections/sony-playstation-4" title="SONY PLAYSTATION 4">
							<span>SONY PLAYSTATION 4</span>
						</a>
					</li>
					
					
					
					<li class="">
						<a href="/collections/phan-mem" title="Phần mềm">
							<span>Phần mềm</span>
						</a>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/thiet-bi-phong-net" title="Thiết bị phòng Net - Game">
							<span>Thiết bị phòng Net - Game</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="odd">
								<a href="/collections/thiet-bi-phong-net-ban-phong-net" title="Bàn phòng net">
									<span>Bàn phòng net</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/thiet-bi-phong-net-ghe-phong-net-gaming" title="Ghế Phòng Net - Gaming">
									<span>Ghế Phòng Net - Gaming</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/thiet-bi-phong-net-linh-kien-phong-game-net" title="Linh kiện phòng Game-Net">
									<span>Linh kiện phòng Game-Net</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub ">
						<a href="/collections/camera-an-ninh" title="Camera An ninh">
							<span>Camera An ninh</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/camera-an-ninh-giai-phap-camera-ahd" title="Giải Pháp Camera AHD">
									<span>Giải Pháp Camera AHD</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/camera-an-ninh-giai-phap-camera-ip" title="Giải pháp Camera IP">
									<span>Giải pháp Camera IP</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
					
					<li class="has-sub last">
						<a href="/collections/linh-kien-khac-1" title="Linh Kiện Khác">
							<span>Linh Kiện Khác</span>
							<span class="sign drop-down-1">
								<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
							</span>
						</a>
						<ul class="nav children collapse lve2-blog">
							
							<li class="even">
								<a href="/collections/linh-kien-khac-pin-du-phong" title="Pin Dự Phòng">
									<span>Pin Dự Phòng</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/linh-kien-khac-fan-controller-fan-hub" title="Fan Controller - Fan Hub">
									<span>Fan Controller - Fan Hub</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/linh-kien-khac-den-ban-cao-cap" title="Đèn bàn cao cấp">
									<span>Đèn bàn cao cấp</span>
								</a>				
							</li>
							
							<li class="odd">
								<a href="/collections/linh-kien-khac-ve-sinh-may-tinh-lcd" title="Vệ sinh Máy tính &amp; LCD">
									<span>Vệ sinh Máy tính &amp; LCD</span>
								</a>				
							</li>
							
							<li class="even">
								<a href="/collections/linh-kien-khac-linh-tinh" title="Linh Tinh">
									<span>Linh Tinh</span>
								</a>				
							</li>
							
						</ul>
					</li>
					
					
				</ul>
			</li>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			<li class="item has-sub active last">
				<a href="#">
					<span class="lbl">Blog</span>
					<span data-toggle="collapse" data-parent="#cssmenu" href="#sub-item-6" class="sign">
						<img src="//hstatic.net/0/0/global/design/theme-default/arrow-down.png">
					</span>
				</a>
				<ul class="nav children collapse" id="sub-item-6">
					
					
					<li class="first current active">
						<a href="/blogs/chuong-trinh-khuyen-mai" title="Promotions">
							<span>Promotions</span>
						</a>
					</li>
					
					
					
					<li class="">
						<a href="/blogs/tin-tuc" title="News">
							<span>News</span>
						</a>
					</li>
					
					
					
					<li class="last">
						<a href="/blogs/goc-review" title="Góc Review">
							<span>Góc Review</span>
						</a>
					</li>
					
					
				</ul>
			</li>
			
			
		</ul>
		<script>
		$(document).ready(function(){
			//$('ul li:has(ul)').addClass('hassub');
			$('#menu-blog ul ul li:odd').addClass('odd');
			$('#menu-blog ul ul li:even').addClass('even');
			$('#menu-blog > ul > li > a').click(function() {
				$('#menu-blog li').removeClass('active');
				$(this).closest('li').addClass('active');
				var checkElement = $(this).nextS();
				if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
					$(this).closest('li').removeClass('active');
					checkElement.slideUp('normal');
				}
				if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
					$('#menu-blog ul ul:visible').slideUp('normal');
					checkElement.slideDown('normal');
				}
				if($(this).closest('li').find('ul').children().length == 0) {
					return true;
				} else {
					return false;
				}
			});

			$('.drop-down-1').click(function(e){		
				if ( $(this).parents('li').hasClass('has-sub') ){
					e.preventDefault();
					if($(this).hasClass('open-nav')){
						$(this).removeClass('open-nav');
						$(this).parents('li').children('ul.lve2-blog').slideUp('normal').removeClass('in');
					}else {
						$(this).addClass('open-nav');
						$(this).parents('li').children('ul.lve2-blog').slideDown('normal').addClass('in');
					}
				}else {

				}
			});

		});

		$(".news-menu  ul.navs li.active").parents('ul.children').addClass("in");
		</script>
	</div>