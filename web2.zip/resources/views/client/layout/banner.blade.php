<!-- Banner quảng cáo -->
<div class="list-group_l banner-left">
	
	<a href="{{route('phuong-thuc-thanh-toan')}}">
		<img src="{{asset('public/assets/images/left_image_ad.jpg?v=772')}}" >
	</a>
	
</div>
<!-- Banner quảng cáo -->
<div class="list-group_2 banner-left">
	
	<a href="{{route('bao-hanh')}}">
		<img src="{{asset('public/assets/images/left_image_ad_2.jpg?v=772')}}" >
	</a>
	
</div>