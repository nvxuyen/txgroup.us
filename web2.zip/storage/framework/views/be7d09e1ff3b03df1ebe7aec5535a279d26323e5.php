<?php $__env->startSection('content'); ?>
<section id="content" class="clearfix container">

							
							

							
<div id="article" class="article-detail clearfix">
	<div class="col-md-12 col-sm-12 col-xs-12 article">
		<div class="main-content">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pd5 blog-breadcrumb ">
	<ol class="breadcrumb breadcrumb-arrow hidden-sm hidden-xs">
		<li><a href="/" target="_self">Trang chủ</a></li>
		
	
		<li><a href="/blogs/chuong-trinh-khuyen-mai">Blog - Chương trình khuyến mãi</a></li>

		<li class="active"><span><?php echo e($read->title); ?></span></li>
		
	</ol>
</div>
			<!-- Begin article -->
			<div class="article-body">
				<div class="col-md-9 articles clearfix" id="layout-page">
					<span class="header-page clearfix">
						<h1><?php echo e($read->title); ?></h1>
					</span>

					<div class="content-page row">
						<div class="col-md-2">
							<!--Begin:ngày giờ đăng bài viết  -->
							<div class="author-date">
								<ul class="date-post">
									<li> 
										<i class="icon-time"></i>
										<p>
											<?php echo e(date_format($read->created_at, "d/m/Y")); ?>

											}
										</p>
									</li>
								</ul>
							</div>
							<!--End:ngày giờ đăng bài viết  -->

							<!--Begin: số bình luận  -->
                            
							<!--End: số đăng bình luận   -->
						</div>

						<div class="col-md-10 article-content">
							
							<div class="body-content">
								<?php echo $read->content; ?>

							</div>

						</div>
                        
					</div>

				</div>   
				<!-- End article--> 


				<!-- Begin sidebar -->
				<div class="col-md-3 clearfix">
					<div class="sidebar">
	
	<!-- Begin: Danh mục tin tức -->
	<?php echo $__env->make('client.page.blog_cat', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<!-- End: Danh mục tin tức -->
	<?php echo $__env->make('client.page.blog_news_post', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>




</div>
					<!-- End sidebar -->
				</div>
			</div>    


		</div>
	</div>
</div>


						</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>