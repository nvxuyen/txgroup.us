						<footer>
							<div class="footer-top">
								<div class="container">
									<div class="row">
										
										<div class="col-md-4 col-sm-4 col-xs-12">
											<div class="footer-static-title">
												<h4>Thời gian làm việc & bảo hành</h4>
											</div>
											<div class="footer-static-content">
												<p>
• Thứ 2 - Thứ 7: 08:00 - 19:30</br>
• Chủ Nhật: 09:00 - 12:00 & 13:30 - 16:00</br>
<b>Bảo Hành: Thứ 2 - Thứ 7</b></br>
• Sáng: 08:30 - 12:00</br>
• Chiều: 13:30 - 18:00<br></p>					
											</div>
										</div>
										
										
										<div class="col-md-4 col-sm-4 col-xs-12">
											<div class="footer-static-title">
												<h4>Thông tin</h4>
											</div>
											<div class="footer-static-content">
												<div class="contact-add">
													
													<p><i class="fa fa-map-marker"></i><span>Địa chỉ: 180 Đường Cao Lỗ, Phường 4, Quận 8, Hồ Chí Minh</br>Bảo hành : 180 Đường Cao Lỗ, Phường 4, Quận 8, Hồ Chí Minh</span></p>
																			
													<p><i class="fa fa-envelope-o"></i><span>txgroup@gmail.com (CSKH) - txgroup@gmail.com (Kinh Doanh) - txgroup@gmail.com (Liên hệ) </span></p>
													
												</div>
											</div>
										</div>
										
									</div>
								</div>

							</div>
							<div class="footer-bottom">
								<div class="container copyright">						
									<p>© 2019 - Bản quyền của cửa hàng VI TÍNH TXGROUP - <a href="<?php echo e(asset('')); ?>" target="_blank">TXGroup.Us</a>.</p> 
									Địa chỉ: 180 Cao Lỗ, Quận 8, TP.HCM, Việt Nam</p>

								</div>
							</div>
						</footer>