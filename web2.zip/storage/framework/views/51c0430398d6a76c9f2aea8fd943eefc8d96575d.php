						<header class="container clearfix">
							<div class="col-md-12 clearfix">
								<div class="logo col-md-3 col-xs-12">
									<!-- LOGO -->
									
									<h1>
										<a href="<?php echo e(asset('')); ?>">
											<img src="<?php echo e(asset('public/assets/images')); ?>/logo.png" alt="Tân Doanh" class="img-responsive"/>
										</a>
									</h1>
									
									<h1 style="display:none">
										<a href="{{asset('')}]">TX Group</a>
									</h1>
									
									
								</div>
								<div class="col-md-9 hidden-xs">
									<!-- BANNER -->
									<div class="banner">
										
										<!--<a href="">
											<img width="100%" src="//theme.hstatic.net/1000162654/1000230569/14/banner-top.jpg?v=772" alt="banner topđasad" class="img-responsive" />
										</a>-->
										
									</div>
								</div>
							</div>
						</header>