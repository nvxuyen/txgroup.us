<?php $__env->startSection('content'); ?>
			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo e(route('trang-chu')); ?>">Home</a>
							</li>

							<li>
								<a href="#">Quản lý tin</a>
							</li>
							<li class="active">Sửa bài viết</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						<?php echo $__env->make('admin.layout.settings_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

						<div class="page-header">
							<h1>
								Sửa bài viết

							</h1>
						</div><!-- /.page-header -->
						<style type="text/css">
							.col-sm-3 {
    							width: 10%;
							}
						</style>
						<div class="row">
							<div class="col-xs-12">
								<?php if(count($errors) > 0): ?>
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="alert alert-warning">
									    <strong>Warning!</strong> <?php echo e($err); ?>

								 	 </div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
								<?php if(session('thongbao')): ?>
								  <div class="alert alert-success">
								    <strong>Success!</strong> <?php echo e(session('thongbao')); ?>.
								  </div>
							  <?php endif; ?>
								<!-- PAGE CONTENT BEGINS -->
								<form class="form-horizontal" role="form" action="<?php echo e(route('admin')); ?>/news/edit/<?php echo e($edit->id); ?>" method="POST">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Tiêu đề </label>

										<div class="col-sm-9">
											<input type="text" id="title" name="title" value="<?php echo e($edit->title); ?>" class="col-xs-10 col-sm-5" />
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2"> Chuyên mục </label>

										<div class="col-sm-9">
											<select style="width:15%;" class="chosen-select form-control" id="cat_news" name="cat_news">
												<?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($c->id); ?>" <?php if(($edit->cat_id) == ($c->id)): ?> selected="selected" <?php endif; ?>><?php echo e($c->name); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>

									<div class="space-4"></div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Tóm tắt </label>

										<div class="col-sm-9">
											<textarea name="quote" id="quote" cols="10" rows="10" style="margin: 0px; width: 835px; height: 83px;"><?php echo e($edit->quote); ?></textarea>
										</div>
									</div>

									<div class="space-4"></div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> URL Ảnh đại diện </label>

										<div class="col-sm-9">
											<input type="text" name="image" value="<?php echo e($edit->image); ?>" class="col-xs-10 col-sm-5" />
										</div>
									</div>

									<div class="space-4"></div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2"> Nội dung </label>
										<div class="col-sm-9">
								            <textarea name="content" id="content" rows="10" cols="80"><?php echo e($edit->content); ?></textarea>
								            <script>
								                // Replace the <textarea id="editor1"> with a CKEditor
								                // instance, using default configuration.
								                CKEDITOR.replace( 'content' );
								            </script>
										</div>
									</div>

									<div class="space-4"></div>

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<button class="btn btn-info" type="submit">
												<i class="ace-icon fa fa-check bigger-110"></i>
												Submit
											</button>

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-head'); ?>
<script src="public/assets_admin/js/ckeditor/ckeditor.js" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>