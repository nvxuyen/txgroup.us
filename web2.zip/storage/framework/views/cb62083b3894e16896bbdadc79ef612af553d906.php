<!-- Support-->
<div class="sidebar-support list-group">
	<span href="#" class="list-group-item active">
		
		<img src="<?php echo e(asset('public/assets/images/avatar-answ.png?v=772')); ?>" class="img-responsive" />
		
	</span>
	<h3> Hỗ trợ trực tuyến</h3>
	<div class="support">
		<div class="text-center">
			<p>
				<span class="supp-name">Kinh Doanh:</span>
				<br>
				<span class="phone">txgroup@gmail.com</span>
			</p>
			
			<a href="skype:lytavn?chat" class="skype">
				<img src="<?php echo e(asset('public')); ?>/assets/images/skype-icon.png" class="img-responsive"/>
			</a>
			
			
		</div>
		<div class="text-center">
			
			<span class="supp-name" >Số hotline	</span>
			
			
			<br>
			<p>
				<b>• Tổng Đài:</b> 0868899000</br> <b>• Kinh Doanh:</b> 0868899000 </br><b>• Kỹ Thuật:</b> 0868899000</br><b>• Bảo Hành:</b> 0868899000 </br>
			</p>
			
		</div>
		<div class="text-center">
			
			<span class="supp-name" >Thời gian làm việc	</span>
			
			<p>
				Thứ 2 - Thứ 7</br> 
• Sáng: 08:00 - 12:00</br>
• Chiều: 13:30 - 18:00</br>

<b>Bảo Hành:</b> Thứ 2 - Thứ 7</br>
• Sáng: 08:30 - 12:00</br>
• Chiều: 13:30 - 18:00<br>
			</p>
		</div>
	</div>
</div>
<!-- Support-->