<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ForgotPass extends Model
{
    protected $table = "forgotpass";
}
